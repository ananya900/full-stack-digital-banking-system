import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

// Interfaces
export interface Account {
  id: number;
  accountNumber: string;
  accountType: string;
  accountName: string;
  ifscCode: string;
  branchName: string;
  branchAddress: string;
  balance: number;
  isActive: boolean;
  openedDate: Date;
  userId: number;
}

export interface AccountRequest {
  id: number;
  user: {
    id: number;
    username: string;
    name: string;
    email: string;
    contactNumber: string;
    address: string;
    dateOfBirth: string;
    aadharNumber: string;
    panNumber: string;
    age: number;
    gender: string;
    roles: any[];
  };
  accountType: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  requestDate: string;
  employeeComments?: string;
  approvedBy?: number;
  approvedDate?: string;
  ifscCode: string;
  branchName: string;
  branchAddress: string;
}

export interface Transaction {
  id: number;
  accountId: number;
  transactionType: 'CREDIT' | 'DEBIT';
  amount: number;
  description: string;
  toAccount?: string;
  fromAccount?: string;
  timestamp: Date;
  balance: number;
}

export interface Beneficiary {
  id: number;
  accountName: string;
  accountNumber: string;
  bankName: string;
  branchName: string;
  ifscCode: string;
  addedDate: Date;
  userId: number;
}

export interface Bank {
  id: number;
  name: string;
  code?: string;
}

export interface Branch {
  id: number;
  name: string;
  address: string;
  ifscCode: string;
  bankName: string;
}

export interface CreateAccountRequest {
  userId: number;
  accountType: string;
  ifscCode: string;
  branchName: string;
  branchAddress: string;
}

export interface CreateBeneficiaryRequest {
  accountName: string;
  accountNumber: string;
  bankName: string;
  branchName: string;
  ifscCode: string;
  userId: number;
}

export interface TransactionFilter {
  type: 'all' | 'last10' | 'lastMonth' | 'dateRange';
  startDate?: string;
  endDate?: string;
}

@Injectable({
  providedIn: 'root'
})
export class AccountManagementService {
  private baseUrl = 'http://localhost:9090/api'; // Updated to match our backend URL

  constructor(
    private http: HttpClient
  ) {}

  // Account APIs
  getUserAccounts(userId: number): Observable<Account[]> {
    return this.http.get<Account[]>(`${this.baseUrl}/accounts/user/${userId}`)
      .pipe(
        catchError((error) => {
          console.error('Error fetching user accounts:', error);
          // Return mock data as fallback
          return of([
            {
              id: 1,
              accountNumber: '1234567890',
              accountType: 'SAVINGS',
              accountName: 'Primary Savings',
              ifscCode: 'MVB0001001',
              branchName: 'Main Branch',
              branchAddress: '123 Main Street',
              balance: 25000.50,
              isActive: true,
              openedDate: new Date('2023-01-15'),
              userId: userId
            }
          ]);
        })
      );
  }

  getAccountByNumber(accountNumber: string): Observable<Account> {
    return this.http.get<Account>(`${this.baseUrl}/accounts/${accountNumber}`);
  }

  // Account Request APIs (for customers)
  submitAccountRequest(request: CreateAccountRequest): Observable<AccountRequest> {
    return this.http.post<AccountRequest>(`${this.baseUrl}/accounts/request`, request);
  }

  getUserAccountRequests(userId: number): Observable<AccountRequest[]> {
    return this.http.get<AccountRequest[]>(`${this.baseUrl}/accounts/requests/user/${userId}`);
  }

  // Account Management APIs (for employees/admins)
  openAccountDirectly(request: CreateAccountRequest): Observable<Account> {
    return this.http.post<Account>(`${this.baseUrl}/accounts/open`, request);
  }

  getPendingAccountRequests(): Observable<AccountRequest[]> {
    return this.http.get<AccountRequest[]>(`${this.baseUrl}/accounts/requests/pending`);
  }

  approveAccountRequest(requestId: number, employeeId: number, comments?: string): Observable<any> {
    const body = { 
      employeeId: employeeId,
      comments: comments || 'Approved'
    };
    return this.http.post(`${this.baseUrl}/accounts/requests/${requestId}/approve`, body);
  }

  rejectAccountRequest(requestId: number, employeeId: number, comments: string): Observable<any> {
    const body = { 
      employeeId: employeeId,
      comments: comments
    };
    return this.http.post(`${this.baseUrl}/accounts/requests/${requestId}/reject`, body);
  }

  // Transaction APIs - Updated to use real backend endpoints
  getAccountTransactions(accountId: number, filter?: TransactionFilter): Observable<Transaction[]> {
    if (filter?.type === 'last10') {
      return this.http.get<Transaction[]>(`${this.baseUrl}/transactions/account/${accountId}/recent?limit=10`)
        .pipe(catchError(() => of(this.getMockTransactions())));
    } else if (filter?.type === 'lastMonth') {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      return this.getTransactionsByDateRange(accountId, firstDay.toISOString().split('T')[0], now.toISOString().split('T')[0]);
    } else if (filter?.type === 'dateRange' && filter.startDate && filter.endDate) {
      return this.getTransactionsByDateRange(accountId, filter.startDate, filter.endDate);
    } else {
      return this.http.get<Transaction[]>(`${this.baseUrl}/transactions/account/${accountId}`)
        .pipe(catchError(() => of(this.getMockTransactions())));
    }
  }

  getLastNTransactions(accountId: number, count: number): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.baseUrl}/transactions/account/${accountId}/recent?limit=${count}`)
      .pipe(catchError(() => of(this.getMockTransactions())));
  }

  getTransactionsByDateRange(accountId: number, startDate: string, endDate: string): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.baseUrl}/transactions/account/${accountId}/date-range?startDate=${startDate}&endDate=${endDate}`)
      .pipe(catchError(() => of(this.getMockTransactions())));
  }

  // New transaction operations
  deposit(accountId: number, amount: number, description?: string): Observable<Transaction> {
    const body = { accountId, amount, description: description || 'Deposit' };
    return this.http.post<Transaction>(`${this.baseUrl}/transactions/deposit`, body);
  }

  withdraw(accountId: number, amount: number, description?: string): Observable<Transaction> {
    const body = { accountId, amount, description: description || 'Withdrawal' };
    return this.http.post<Transaction>(`${this.baseUrl}/transactions/withdraw`, body);
  }

  transfer(fromAccountId: number, toAccountId: number, amount: number, description?: string): Observable<Transaction> {
    const body = { fromAccountId, toAccountId, amount, description: description || 'Fund Transfer' };
    return this.http.post<Transaction>(`${this.baseUrl}/transactions/transfer`, body);
  }

  transferByAccountNumber(fromAccountId: number, toAccountNumber: string, amount: number, description?: string): Observable<Transaction> {
    const body = { fromAccountId, toAccountNumber, amount, description: description || 'Fund Transfer' };
    return this.http.post<Transaction>(`${this.baseUrl}/transactions/transfer-by-account-number`, body);
  }

  transferToBeneficiary(fromAccountId: number, beneficiaryId: number, amount: number, description?: string): Observable<Transaction> {
    const body = { fromAccountId, beneficiaryId, amount, description: description || 'Transfer to Beneficiary' };
    return this.http.post<Transaction>(`${this.baseUrl}/transactions/transfer-to-beneficiary`, body);
  }

  getUserRecentTransactions(userId: number, limit: number = 10): Observable<Transaction[]> {
    return this.http.get<Transaction[]>(`${this.baseUrl}/transactions/user/${userId}/recent?limit=${limit}`)
      .pipe(catchError(() => of(this.getMockTransactions())));
  }

  // Mock data fallback method
  private getMockTransactions(): Transaction[] {
    return [
      {
        id: 1,
        accountId: 1,
        transactionType: 'CREDIT',
        amount: 1000.00,
        description: 'Initial Deposit',
        timestamp: new Date('2024-01-15T10:30:00'),
        balance: 26000.50
      },
      {
        id: 2,
        accountId: 1,
        transactionType: 'DEBIT',
        amount: 50.00,
        description: 'ATM Withdrawal',
        timestamp: new Date('2024-01-14T15:45:00'),
        balance: 25000.50
      }
    ];
  }
}
