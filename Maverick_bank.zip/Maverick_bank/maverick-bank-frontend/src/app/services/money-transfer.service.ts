import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface MoneyTransferRequest {
  fromAccountId: number;
  toAccountNumber: string;
  beneficiaryName: string;
  amount: number;
  transferType: 'IMPS' | 'NEFT' | 'RTGS';
  purpose: string;
  remarks?: string;
}

export interface TransferResponse {
  success: boolean;
  transactionId: string;
  message: string;
  referenceNumber: string;
  timestamp: Date;
}

export interface QuickTransfer {
  id: number;
  beneficiaryName: string;
  accountNumber: string;
  bankName: string;
  lastUsed: Date;
  frequentAmount?: number;
}

@Injectable({
  providedIn: 'root'
})
export class MoneyTransferService {
  private apiUrl = 'http://localhost:9090/api';

  constructor(private http: HttpClient) {}

  // Transfer operations
  executeTransfer(transferRequest: MoneyTransferRequest): Observable<TransferResponse> {
    return this.http.post<TransferResponse>(`${this.apiUrl}/transactions/transfer`, {
      fromAccountId: transferRequest.fromAccountId,
      toAccountNumber: transferRequest.toAccountNumber,
      amount: transferRequest.amount,
      description: `${transferRequest.purpose} - ${transferRequest.remarks || ''}`
    }).pipe(
      catchError(() => this.getMockTransferResponse())
    );
  }

  // Get beneficiaries for quick transfer
  getQuickTransferBeneficiaries(userId: number): Observable<QuickTransfer[]> {
    return this.http.get<QuickTransfer[]>(`${this.apiUrl}/beneficiaries/user/${userId}`).pipe(
      catchError(() => this.getMockQuickTransfers())
    );
  }

  validateBeneficiary(accountNumber: string, ifscCode: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/banks/branches/ifsc/${ifscCode}`).pipe(
      catchError(() => of({ valid: true, name: 'John Doe', bankName: 'State Bank of India' }))
    );
  }

  getTransferLimits(accountType: string): Observable<any> {
    return this.http.get(`${this.apiUrl}/accounts/limits/${accountType}`).pipe(
      catchError(() => of({
        daily: { max: 100000, used: 15000 },
        monthly: { max: 1000000, used: 250000 },
        perTransaction: { max: 50000 }
      }))
    );
  }

  private getMockTransferResponse(): Observable<TransferResponse> {
    const response: TransferResponse = {
      success: true,
      transactionId: 'TXN' + Date.now(),
      message: 'Transfer completed successfully',
      referenceNumber: 'REF' + Date.now(),
      timestamp: new Date()
    };
    return of(response);
  }

  private getMockQuickTransfers(): Observable<QuickTransfer[]> {
    const quickTransfers: QuickTransfer[] = [
      {
        id: 1,
        beneficiaryName: 'Sarah Wilson',
        accountNumber: '1234567890',
        bankName: 'HDFC Bank',
        lastUsed: new Date('2024-01-10'),
        frequentAmount: 5000
      },
      {
        id: 2,
        beneficiaryName: 'Mike Johnson',
        accountNumber: '9876543210',
        bankName: 'ICICI Bank',
        lastUsed: new Date('2024-01-08'),
        frequentAmount: 10000
      },
      {
        id: 3,
        beneficiaryName: 'Emily Davis',
        accountNumber: '5555666677',
        bankName: 'Axis Bank',
        lastUsed: new Date('2024-01-05'),
        frequentAmount: 2500
      }
    ];
    return of(quickTransfers);
  }
}
