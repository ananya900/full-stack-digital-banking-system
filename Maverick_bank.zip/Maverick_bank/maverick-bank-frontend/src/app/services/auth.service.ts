import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject, of } from 'rxjs';
import { map, switchMap, catchError } from 'rxjs/operators';

export interface LoginRequest {
  username: string;
  password: string;
}

export interface RegisterRequest {
  username: string;
  password: string;
  name: string;
  email: string;
  contactNumber: string;
  address: string;
  dateOfBirth: string;
  aadharNumber: string;
  panNumber: string;
  gender: string;
}

export interface AuthResponse {
  token: string;
}

export interface User {
  id: number;
  username: string;
  name: string;
  email: string;
  roles: any[];
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'http://localhost:9090/api'; // Direct backend URL
  private tokenKey = 'auth_token';
  private userSubject = new BehaviorSubject<User | null>(null);
  public user$ = this.userSubject.asObservable();


  constructor(private http: HttpClient) {
    // Restore token and user from localStorage if present and valid
    const token = localStorage.getItem(this.tokenKey);
    const savedUser = localStorage.getItem('user');
    
    if (token && !this.isTokenExpired(token)) {
      // If we have a saved user, restore it immediately
      if (savedUser) {
        try {
          const user = JSON.parse(savedUser);
          this.userSubject.next(user);
        } catch (error) {
          console.error('Error parsing saved user:', error);
          this.logout();
        }
      } else {
        // Try to load user profile if not already saved
        this.loadUserProfile();
      }
    } else {
      this.logout();
    }
  }

  login(credentials: LoginRequest): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.baseUrl}/auth/login`, credentials)
      .pipe(
        switchMap((response: AuthResponse) => {
          if (response.token) {
            localStorage.setItem(this.tokenKey, response.token);
            // Create headers with the new token
            const headers = new HttpHeaders({
              'Authorization': `Bearer ${response.token}`,
              'Content-Type': 'application/json'
            });
            // Load user profile and wait for it to complete
            return this.http.get<User>(`${this.baseUrl}/users/profile`, { headers }).pipe(
              map((user: User) => {
                this.userSubject.next(user);
                localStorage.setItem('user', JSON.stringify(user)); // Save user to localStorage
                return response;
              }),
              // If profile loading fails, create a basic user object from credentials
              catchError(() => {
                const basicUser: User = {
                  id: 0,
                  username: credentials.username,
                  name: credentials.username,
                  email: credentials.username + '@maverick.com',
                  roles: [{ id: 1, name: 'CUSTOMER' }]
                };
                this.userSubject.next(basicUser);
                localStorage.setItem('user', JSON.stringify(basicUser)); // Save user to localStorage
                return of(response);
              })
            );
          }
          return of(response);
        })
      );
  }

  register(userData: RegisterRequest): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    });

    return this.http.post(`${this.baseUrl}/auth/register`, userData, { headers });
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem('user');
    this.userSubject.next(null);
  }

  getToken(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  isAuthenticated(): boolean {
    const token = this.getToken();
    return token !== null && !this.isTokenExpired(token);
  }

  getCurrentUser(): User | null {
    return this.userSubject.value;
  }

  getAuthHeaders(): HttpHeaders {
    const token = this.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    });
  }

  private checkAuthStatus(): void {
    if (this.isAuthenticated()) {
      this.loadUserProfile();
    }
  }

  public loadUserProfile(): void {
    this.http.get<User>(`${this.baseUrl}/users/profile`, {
      headers: this.getAuthHeaders()
    }).subscribe({
      next: (user) => {
        this.userSubject.next(user);
        localStorage.setItem('user', JSON.stringify(user)); // Save user to localStorage
      },
      error: () => this.logout()
    });
  }

  public isTokenExpired(token: string): boolean {
    try {
      const expiry = (JSON.parse(atob(token.split('.')[1]))).exp;
      return (Math.floor((new Date).getTime() / 1000)) >= expiry;
    } catch {
      return true;
    }
  }
}
