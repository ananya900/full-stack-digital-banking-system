import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { NotificationService } from './notification.service';

export interface NavigationPreferences {
  useRoleSpecificDashboards: boolean;
  defaultDashboard: string;
}

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  private preferences: NavigationPreferences = {
    useRoleSpecificDashboards: false, // Default to unified dashboard
    defaultDashboard: '/dashboard'
  };

  private roleRoutes: { [key: string]: string } = {
    'CUSTOMER': '/customer-dashboard',
    'EMPLOYEE': '/employee-dashboard',
    'ADMIN': '/admin-dashboard'
  };

  constructor(
    private router: Router,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {
    this.loadPreferences();
  }

  navigateToRoleDashboard(): void {
    this.authService.user$.subscribe(user => {
      if (!user) return;

      const userRole = user.roles[0]?.name || 'CUSTOMER';
      
      if (this.preferences.useRoleSpecificDashboards) {
        const targetRoute = this.roleRoutes[userRole];
        if (targetRoute) {
          this.router.navigate([targetRoute]);
          this.notificationService.info(`Navigated to ${userRole.toLowerCase()} dashboard`);
        }
      } else {
        this.router.navigate(['/dashboard']);
      }
    }).unsubscribe();
  }

  toggleRoleSpecificDashboards(): void {
    this.preferences.useRoleSpecificDashboards = !this.preferences.useRoleSpecificDashboards;
    this.savePreferences();
    
    const message = this.preferences.useRoleSpecificDashboards 
      ? 'Enabled role-specific dashboards' 
      : 'Using unified dashboard';
    this.notificationService.info(message);
  }

  getRoleRoute(role: string): string {
    return this.roleRoutes[role] || '/dashboard';
  }

  getCurrentDashboardType(): 'unified' | 'role-specific' {
    return this.preferences.useRoleSpecificDashboards ? 'role-specific' : 'unified';
  }

  private loadPreferences(): void {
    const saved = localStorage.getItem('navigation-preferences');
    if (saved) {
      try {
        this.preferences = { ...this.preferences, ...JSON.parse(saved) };
      } catch (e) {
        console.warn('Failed to load navigation preferences:', e);
      }
    }
  }

  private savePreferences(): void {
    try {
      localStorage.setItem('navigation-preferences', JSON.stringify(this.preferences));
    } catch (e) {
      console.warn('Failed to save navigation preferences:', e);
    }
  }
}
