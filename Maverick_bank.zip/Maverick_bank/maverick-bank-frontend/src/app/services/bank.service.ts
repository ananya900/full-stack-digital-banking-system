import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

export interface Bank {
  id: number;
  name: string;
  code?: string;
  establishedYear?: number;
  headquarters?: string;
}

export interface Branch {
  id: number;
  name: string;
  address: string;
  ifscCode: string;
  bankName: string;
  phone?: string;
  email?: string;
  city?: string;
  state?: string;
  pincode?: string;
}

@Injectable({
  providedIn: 'root'
})
export class BankService {
  private apiUrl = 'http://localhost:9090/api/banks';

  constructor(private http: HttpClient) {}

  getAllBanks(): Observable<Bank[]> {
    return this.http.get<Bank[]>(`${this.apiUrl}`).pipe(
      catchError(() => this.getMockBanks())
    );
  }

  getBankById(id: number): Observable<Bank> {
    return this.http.get<Bank>(`${this.apiUrl}/${id}`).pipe(
      catchError(() => this.getMockBankById(id))
    );
  }

  getAllBranches(): Observable<Branch[]> {
    return this.http.get<Branch[]>(`${this.apiUrl}/branches`).pipe(
      catchError(() => this.getMockBranches())
    );
  }

  getBranchesByBankName(bankName: string): Observable<Branch[]> {
    return this.http.get<Branch[]>(`${this.apiUrl}/${encodeURIComponent(bankName)}/branches`).pipe(
      catchError(() => this.getMockBranchesByBank(bankName))
    );
  }

  getBranchByIfscCode(ifscCode: string): Observable<Branch> {
    return this.http.get<Branch>(`${this.apiUrl}/branches/ifsc/${ifscCode}`).pipe(
      catchError(() => this.getMockBranchByIfsc(ifscCode))
    );
  }

  searchBranches(query: string): Observable<Branch[]> {
    return this.http.get<Branch[]>(`${this.apiUrl}/branches/search?q=${encodeURIComponent(query)}`).pipe(
      catchError(() => this.getMockBranches())
    );
  }

  private getMockBanks(): Observable<Bank[]> {
    const mockBanks: Bank[] = [
      { id: 1, name: 'State Bank of India', code: 'SBI', establishedYear: 1955, headquarters: 'Mumbai' },
      { id: 2, name: 'HDFC Bank', code: 'HDFC', establishedYear: 1994, headquarters: 'Mumbai' },
      { id: 3, name: 'ICICI Bank', code: 'ICICI', establishedYear: 1994, headquarters: 'Mumbai' },
      { id: 4, name: 'Axis Bank', code: 'AXIS', establishedYear: 1993, headquarters: 'Mumbai' },
      { id: 5, name: 'Kotak Mahindra Bank', code: 'KOTAK', establishedYear: 2003, headquarters: 'Mumbai' },
      { id: 6, name: 'Maverick Bank', code: 'MVB', establishedYear: 2020, headquarters: 'Bangalore' }
    ];
    return of(mockBanks);
  }

  private getMockBankById(id: number): Observable<Bank> {
    const mockBank: Bank = { id, name: 'Unknown Bank', code: 'UNK' };
    return of(mockBank);
  }

  private getMockBranches(): Observable<Branch[]> {
    const mockBranches: Branch[] = [
      {
        id: 1,
        name: 'Main Branch',
        address: '123 Main Street, Mumbai',
        ifscCode: 'MVB0001001',
        bankName: 'Maverick Bank',
        phone: '+91-22-12345678',
        email: 'main@maverickbank.com',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400001'
      },
      {
        id: 2,
        name: 'Andheri Branch',
        address: '456 Andheri West, Mumbai',
        ifscCode: 'MVB0001002',
        bankName: 'Maverick Bank',
        phone: '+91-22-87654321',
        email: 'andheri@maverickbank.com',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400058'
      },
      {
        id: 3,
        name: 'Bangalore Branch',
        address: '789 MG Road, Bangalore',
        ifscCode: 'MVB0002001',
        bankName: 'Maverick Bank',
        phone: '+91-80-12345678',
        email: 'bangalore@maverickbank.com',
        city: 'Bangalore',
        state: 'Karnataka',
        pincode: '560001'
      }
    ];
    return of(mockBranches);
  }

  private getMockBranchesByBank(bankName: string): Observable<Branch[]> {
    return this.getMockBranches().pipe(
      catchError(() => of([]))
    );
  }

  private getMockBranchByIfsc(ifscCode: string): Observable<Branch> {
    const branch: Branch = {
      id: 1,
      name: 'Main Branch',
      address: '123 Main Street, Mumbai',
      ifscCode: ifscCode,
      bankName: 'Maverick Bank',
      phone: '+91-22-12345678',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001'
    };
    return of(branch);
  }
}
