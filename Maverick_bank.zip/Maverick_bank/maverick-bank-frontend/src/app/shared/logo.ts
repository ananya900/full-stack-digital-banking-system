// Fallback logo as base64 - simple M logo
export const FALLBACK_LOGO = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiByeD0iOCIgZmlsbD0iIzFGMkEzNyIvPgo8cGF0aCBkPSJNOCAzMlYxMkg5LjJMMTQgMjEuNkwxOC44IDEySDIwVjMySDEyVjE5LjJMMTQgMjNIMTZMMTggMTkuMlYzMkg4WiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cg==';

export const LOGO_PATHS = [
  'assets/images/maverick-logo.png',
  '/images/maverick-logo.png',
  'images/maverick-logo.png',
  FALLBACK_LOGO
];
