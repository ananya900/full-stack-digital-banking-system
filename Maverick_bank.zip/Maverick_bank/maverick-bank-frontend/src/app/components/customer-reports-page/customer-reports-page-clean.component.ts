import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../services/report.service';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-customer-reports-page',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './customer-reports-page.component.html',
  styleUrls: ['./customer-reports-page.component.css']
})
export class CustomerReportsPageComponent implements OnInit {
  isLoading = false;
  loadingMessage = '';
  
  // Debug information
  debugInfo = {
    userId: '',
    dataLoaded: false,
    lastError: '',
    apiCalls: [] as string[]
  };
  
  // Statement related properties
  selectedStatementPeriod = '';
  currentStatement: any = null;
  
  // Transaction history properties
  selectedHistoryPeriod = '';
  transactionHistory: any[] = [];
  
  // User accounts
  userAccounts: any[] = [];
  selectedAccountId = '';

  constructor(
    private reportService: ReportService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit() {
    this.initializeComponent();
  }

  private initializeComponent() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.debugInfo.userId = user.id?.toString() || user.username;
      this.loadUserAccounts();
    } else {
      this.debugInfo.lastError = 'No user session found';
    }
  }

  private loadUserAccounts() {
    this.debugInfo.apiCalls.push('loadUserAccounts');
    // Mock data for demonstration
    this.userAccounts = [
      {
        id: '1',
        accountNumber: '1234567890',
        accountType: 'Savings',
        balance: 50000
      }
    ];
    this.debugInfo.dataLoaded = true;
  }

  onStatementPeriodChange() {
    this.currentStatement = null;
  }

  onHistoryPeriodChange() {
    this.transactionHistory = [];
  }

  generateStatement() {
    if (!this.selectedStatementPeriod) return;
    
    this.isLoading = true;
    this.loadingMessage = 'Generating account statement...';
    this.debugInfo.apiCalls.push('generateStatement');
    
    // Mock statement generation
    setTimeout(() => {
      this.currentStatement = {
        accountNumber: '1234567890',
        period: this.selectedStatementPeriod,
        generatedDate: new Date(),
        openingBalance: 45000,
        closingBalance: 50000,
        totalCredits: 25000,
        totalDebits: 20000,
        transactions: [
          {
            date: new Date('2024-01-15'),
            description: 'Salary Credit',
            type: 'CREDIT',
            amount: 25000,
            balance: 70000
          },
          {
            date: new Date('2024-01-10'),
            description: 'ATM Withdrawal',
            type: 'DEBIT',
            amount: 5000,
            balance: 45000
          }
        ]
      };
      this.isLoading = false;
      this.notificationService.success('Statement generated successfully');
    }, 2000);
  }

  downloadStatement() {
    if (!this.currentStatement) return;
    
    this.debugInfo.apiCalls.push('downloadStatement');
    this.notificationService.info('PDF download will be implemented');
  }

  loadTransactionHistory() {
    if (!this.selectedHistoryPeriod) return;
    
    this.isLoading = true;
    this.loadingMessage = 'Loading transaction history...';
    this.debugInfo.apiCalls.push('loadTransactionHistory');
    
    // Mock transaction history
    setTimeout(() => {
      this.transactionHistory = [
        {
          date: new Date('2024-01-15'),
          description: 'Salary Credit',
          type: 'CREDIT',
          amount: 25000
        },
        {
          date: new Date('2024-01-12'),
          description: 'Online Purchase',
          type: 'DEBIT',
          amount: 1500
        },
        {
          date: new Date('2024-01-10'),
          description: 'ATM Withdrawal',
          type: 'DEBIT',
          amount: 5000
        }
      ];
      this.isLoading = false;
      this.notificationService.success('Transaction history loaded successfully');
    }, 1500);
  }

  exportTransactions() {
    if (this.transactionHistory.length === 0) return;
    
    this.debugInfo.apiCalls.push('exportTransactions');
    this.notificationService.info('CSV export will be implemented');
  }
}
