import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { MoneyTransferService, MoneyTransferRequest, QuickTransfer } from '../../services/money-transfer.service';
import { AccountManagementService, Account } from '../../services/account-management.service';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-money-transfer',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './money-transfer.component.html',
  styleUrls: ['./money-transfer.component.css']
})
export class MoneyTransferComponent implements OnInit {
  currentStep = 1;
  userAccounts: Account[] = [];
  quickTransfers: QuickTransfer[] = [];
  
  transferRequest: MoneyTransferRequest = {
    fromAccountId: 0,
    toAccountNumber: '',
    beneficiaryName: '',
    amount: 0,
    transferType: 'IMPS',
    purpose: '',
    remarks: ''
  };

  selectedAccount: Account | null = null;
  transferLimits: any = {};
  isLoading = false;
  showConfirmation = false;
  transferResult: any = null;

  transferTypes = [
    { value: 'IMPS', label: 'IMPS (Immediate)', description: 'Instant transfer available 24/7' },
    { value: 'NEFT', label: 'NEFT (National Electronic)', description: 'Available on working days' },
    { value: 'RTGS', label: 'RTGS (Real Time)', description: 'For amounts above ₹2,00,000' }
  ];

  transferPurposes = [
    'Family Support',
    'Business Payment',
    'Personal Transfer',
    'Bill Payment',
    'EMI Payment',
    'Investment',
    'Others'
  ];

  constructor(
    private moneyTransferService: MoneyTransferService,
    private accountService: AccountManagementService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.loadUserData();
  }

  loadUserData(): void {
    this.authService.user$.subscribe(user => {
      if (user) {
        this.loadUserAccounts(user.id);
        this.loadQuickTransfers(user.id);
      }
    });
  }

  loadUserAccounts(userId: number): void {
    this.accountService.getUserAccounts(userId).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts.filter(acc => acc.isActive);
      },
      error: (error) => {
        console.error('Error loading accounts:', error);
        this.notificationService.error('Failed to load your accounts');
      }
    });
  }

  loadQuickTransfers(userId: number): void {
    this.moneyTransferService.getQuickTransferBeneficiaries(userId).subscribe({
      next: (transfers) => {
        this.quickTransfers = transfers;
      },
      error: (error) => {
        console.error('Error loading quick transfers:', error);
      }
    });
  }

  selectAccount(account: Account): void {
    this.selectedAccount = account;
    this.transferRequest.fromAccountId = account.id;
    this.loadTransferLimits(account.accountType);
    this.nextStep();
  }

  loadTransferLimits(accountType: string): void {
    this.moneyTransferService.getTransferLimits(accountType).subscribe({
      next: (limits) => {
        this.transferLimits = limits;
      },
      error: (error) => {
        console.error('Error loading transfer limits:', error);
      }
    });
  }

  selectQuickTransfer(quickTransfer: QuickTransfer): void {
    this.transferRequest.toAccountNumber = quickTransfer.accountNumber;
    this.transferRequest.beneficiaryName = quickTransfer.beneficiaryName;
    if (quickTransfer.frequentAmount) {
      this.transferRequest.amount = quickTransfer.frequentAmount;
    }
    this.nextStep();
  }

  nextStep(): void {
    if (this.validateCurrentStep()) {
      this.currentStep++;
    }
  }

  previousStep(): void {
    this.currentStep--;
  }

  validateCurrentStep(): boolean {
    switch (this.currentStep) {
      case 1:
        if (!this.selectedAccount) {
          this.notificationService.error('Please select an account');
          return false;
        }
        break;
      case 2:
        if (!this.transferRequest.toAccountNumber || !this.transferRequest.beneficiaryName) {
          this.notificationService.error('Please enter beneficiary details');
          return false;
        }
        break;
      case 3:
        if (this.transferRequest.amount <= 0) {
          this.notificationService.error('Please enter a valid amount');
          return false;
        }
        if (this.transferRequest.amount > this.selectedAccount!.balance) {
          this.notificationService.error('Insufficient balance');
          return false;
        }
        if (!this.transferRequest.purpose) {
          this.notificationService.error('Please select transfer purpose');
          return false;
        }
        break;
    }
    return true;
  }

  showTransferConfirmation(): void {
    if (this.validateCurrentStep()) {
      this.showConfirmation = true;
    }
  }

  executeTransfer(): void {
    this.isLoading = true;
    this.moneyTransferService.executeTransfer(this.transferRequest).subscribe({
      next: (result) => {
        this.transferResult = result;
        this.isLoading = false;
        this.showConfirmation = false;
        this.currentStep = 5; // Success step
        this.notificationService.success('Transfer completed successfully!');
      },
      error: (error) => {
        console.error('Transfer failed:', error);
        this.isLoading = false;
        this.notificationService.error('Transfer failed. Please try again.');
      }
    });
  }

  startNewTransfer(): void {
    this.currentStep = 1;
    this.transferRequest = {
      fromAccountId: 0,
      toAccountNumber: '',
      beneficiaryName: '',
      amount: 0,
      transferType: 'IMPS',
      purpose: '',
      remarks: ''
    };
    this.selectedAccount = null;
    this.transferResult = null;
    this.showConfirmation = false;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getRemainingLimit(type: string): number {
    if (!this.transferLimits[type]) return 0;
    return this.transferLimits[type].max - this.transferLimits[type].used;
  }
}
