import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService, User } from '../../../services/auth.service';
import { NotificationService } from '../../../services/notification.service';
import { UserManagementComponent } from '../../user-management/user-management.component';
import { LoanTypeManagementComponent } from '../../loan-type-management/loan-type-management.component';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, UserManagementComponent, LoanTypeManagementComponent],
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {
  user: User | null = null;
  showUserManagement = false;
  showLoanTypeManagement = false;

  // Admin statistics
  totalUsers = 1247;
  totalAccounts = 892;
  totalDeposits = 2.5; // In Crores
  activeLoans = 156;

  constructor(
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      this.loadAdminDashboard();
    });
  }

  loadAdminDashboard(): void {
    // Load admin-specific data
    this.notificationService.info('Loading admin dashboard...');
  }

  onManageUsers(): void {
    this.showUserManagement = true;
    this.showLoanTypeManagement = false;
    this.notificationService.info('Opening User Management System...');
  }

  onManageLoanTypes(): void {
    this.showLoanTypeManagement = true;
    this.showUserManagement = false;
    this.notificationService.info('Opening Loan Type Management System...');
  }

  onSystemReports(): void {
    this.notificationService.info('System reports feature will be available soon!');
  }

  onBankSettings(): void {
    this.notificationService.info('Bank settings feature will be available soon!');
  }

  onAuditLogs(): void {
    this.notificationService.info('Audit logs feature will be available soon!');
  }

  onBackupSystem(): void {
    this.notificationService.info('System backup feature will be available soon!');
  }

  backToDashboard(): void {
    this.showUserManagement = false;
    this.showLoanTypeManagement = false;
    this.notificationService.info('Returning to dashboard...');
  }
}
