import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { AuthService, User } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';
import { NavigationService } from '../../services/navigation.service';
import { AccountManagementService, Account, AccountRequest } from '../../services/account-management.service';
import { NotificationComponent } from '../notifications/notification.component';
import { UserManagementComponent } from '../user-management/user-management.component';
import { LOGO_PATHS } from '../../shared/logo';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterModule, UserManagementComponent],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  user: User | null = null;
  userRole: string = '';
  userAccounts: Account[] = [];
  isLoadingAccounts = false;
  
  // Employee data
  pendingAccountRequests: AccountRequest[] = [];
  isLoadingRequests = false;
  
  // Temporary toggle for testing different role dashboards
  availableRoles = ['CUSTOMER', 'EMPLOYEE', 'ADMIN'];
  
  // Admin view state
  showUserManagement = false;
  
  // Modern UI state
  sidebarCollapsed = false;
  profileDropdownOpen = false;

  private logoIndex = 0;

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService,
    private navigationService: NavigationService,
    private accountService: AccountManagementService
  ) {}

  ngOnInit(): void {
    this.authService.user$.subscribe(user => {
      this.user = user;
      // Get role from actual user data from backend (fallback to CUSTOMER for now)
      this.userRole = user?.roles[0]?.name || 'CUSTOMER';
      
      // Redirect to role-specific dashboard if user prefers dedicated views
      // (keeping current unified dashboard as default for now)
      // this.redirectToRoleDashboard();
      
      // Load user accounts if customer
      if (user && this.isCustomer()) {
        this.loadUserAccounts();
      }
      
      // Load pending requests if employee
      if (user && this.isEmployee()) {
        this.loadPendingRequests();
      }
    });
  }

  // Optional method to redirect to role-specific dashboards
  redirectToRoleDashboard(): void {
    const roleRoutes: { [key: string]: string } = {
      'CUSTOMER': '/customer-dashboard',
      'EMPLOYEE': '/employee-dashboard', 
      'ADMIN': '/admin-dashboard'
    };
    
    const targetRoute = roleRoutes[this.userRole];
    if (targetRoute && this.router.url === '/dashboard') {
      this.router.navigate([targetRoute]);
    }
  }

  // Load user accounts
  loadUserAccounts(): void {
    if (!this.user?.id) return;
    
    this.isLoadingAccounts = true;
    this.accountService.getUserAccounts(this.user.id).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts;
        this.isLoadingAccounts = false;
        console.log('Loaded user accounts:', accounts);
      },
      error: (error) => {
        console.error('Error loading user accounts:', error);
        this.isLoadingAccounts = false;
        this.notificationService.error('Failed to load your accounts');
      }
    });
  }

  // Load pending account requests for employees
  loadPendingRequests(): void {
    this.isLoadingRequests = true;
    this.accountService.getPendingAccountRequests().subscribe({
      next: (requests) => {
        this.pendingAccountRequests = requests;
        this.isLoadingRequests = false;
        console.log('Loaded pending requests:', requests);
      },
      error: (error) => {
        console.error('Error loading pending requests:', error);
        this.isLoadingRequests = false;
        this.notificationService.error('Failed to load pending requests');
      }
    });
  }

  // Approve account request
  approveRequest(requestId: number): void {
    if (!this.user) {
      this.notificationService.error('User not authenticated');
      return;
    }
    
    const comments = prompt('Please provide approval comments (optional):') || 'Approved';
    
    this.accountService.approveAccountRequest(requestId, this.user.id, comments).subscribe({
      next: (response) => {
        this.notificationService.success('Account request approved successfully!');
        // Reload pending requests to update the list
        this.loadPendingRequests();
      },
      error: (error) => {
        console.error('Error approving request:', error);
        this.notificationService.error('Failed to approve account request');
      }
    });
  }

  // Reject account request
  rejectRequest(requestId: number, comments?: string): void {
    if (!this.user) {
      this.notificationService.error('User not authenticated');
      return;
    }
    
    const rejectionComments = comments || prompt('Please provide a reason for rejection:');
    if (!rejectionComments || rejectionComments.trim() === '') {
      this.notificationService.error('Comments are required for rejection');
      return;
    }
    
    this.accountService.rejectAccountRequest(requestId, this.user.id, rejectionComments.trim()).subscribe({
      next: (response) => {
        this.notificationService.success('Account request rejected successfully!');
        // Reload pending requests to update the list
        this.loadPendingRequests();
      },
      error: (error) => {
        console.error('Error rejecting request:', error);
        this.notificationService.error('Failed to reject account request');
      }
    });
  }

  // Temporary method for testing different dashboards
  switchRole(role: string): void {
    this.userRole = role;
    this.notificationService.info(`Switched to ${role} dashboard view for testing`);
    
    // Load appropriate data for the role
    if (role === 'CUSTOMER' && this.user) {
      this.loadUserAccounts();
    } else if (role === 'EMPLOYEE') {
      this.loadPendingRequests();
    }
  }

  // Get slider position for the toggle animation
  getSliderPosition(): string {
    switch (this.userRole) {
      case 'CUSTOMER':
        return 'translateX(0%)';
      case 'EMPLOYEE':
        return 'translateX(100%)';
      case 'ADMIN':
        return 'translateX(200%)';
      default:
        return 'translateX(0%)';
    }
  }

  // Role checking methods
  isCustomer(): boolean {
    return this.userRole === 'CUSTOMER';
  }

  isEmployee(): boolean {
    return this.userRole === 'EMPLOYEE';
  }

  isAdmin(): boolean {
    return this.userRole === 'ADMIN';
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/']);
    this.notificationService.success('Logged out successfully');
  }

  // Quick Action Handlers
  onRequestAccount(): void {
    this.router.navigate(['/request-account']);
  }

  onTransferMoney(): void {
    this.notificationService.info('Money Transfer feature will be available soon!');
  }

  onPayBills(): void {
    this.notificationService.info('Bill Payment feature will be available soon!');
  }

  onAddBeneficiary(): void {
    this.notificationService.info('Add Beneficiary feature will be available soon!');
  }

  onViewStatements(): void {
    this.notificationService.info('Account Statements feature will be available soon!');
  }

  onApplyLoan(): void {
    this.notificationService.info('Loan Application feature will be available soon!');
  }

  onContactSupport(): void {
    this.notificationService.info('Support chat will be available soon!');
  }

  onViewAllTransactions(): void {
    this.notificationService.info('Transaction history feature will be available soon!');
  }

  // Employee-specific action handlers
  onReviewAccountRequests(): void {
    this.router.navigate(['/employee-accounts']);
  }

  onApproveLoan(): void {
    this.router.navigate(['/loan-management']);
    this.notificationService.info('Opening Loan Approval System...');
  }

  onCustomerSupport(): void {
    this.notificationService.info('Customer support feature will be available soon!');
  }

  onGenerateReports(): void {
    this.notificationService.info('Report generation feature will be available soon!');
  }

  onSearchCustomer(): void {
    this.notificationService.info('Customer search feature will be available soon!');
  }

  onOpenAccount(): void {
    this.router.navigate(['/employee-accounts']);
  }

  // Admin-specific action handlers
  onManageUsers(): void {
    this.showUserManagement = true;
    this.notificationService.info('Opening User Management System...');
  }

  onManageLoanTypes(): void {
    this.router.navigate(['/loan-type-management']);
    this.notificationService.info('Opening Loan Type Management...');
  }

  onManageEmployees(): void {
    this.notificationService.info('Employee management feature will be available soon!');
  }

  onSystemReports(): void {
    this.notificationService.info('System reports feature will be available soon!');
  }

  onBankSettings(): void {
    this.notificationService.info('Bank settings feature will be available soon!');
  }

  onAuditLogs(): void {
    this.notificationService.info('Audit logs feature will be available soon!');
  }

  onBackupSystem(): void {
    this.notificationService.info('System backup feature will be available soon!');
  }

  // Navigate back to dashboard
  backToDashboard(): void {
    this.showUserManagement = false;
    this.notificationService.info('Returning to dashboard...');
  }

  // Loan Management Methods
  openLoanManagement(): void {
    this.router.navigate(['/loan-management']);
    this.notificationService.info('Opening Loan Management...');
  }

  // Account management methods
  selectAccount(account: Account): void {
    // Navigate to account management with the selected account
    this.router.navigate(['/accounts'], { 
      queryParams: { 
        accountId: account.id,
        accountNumber: account.accountNumber 
      } 
    });
  }

  getTotalBalance(): number {
    return this.userAccounts.reduce((total, account) => total + account.balance, 0);
  }

  getActiveAccountsCount(): number {
    return this.userAccounts.filter(account => account.isActive).length;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  openAccountManagement(): void {
    this.router.navigate(['/accounts']);
  }

  // Utility method to format date
  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  // Modern UI Methods
  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  toggleProfileDropdown(): void {
    this.profileDropdownOpen = !this.profileDropdownOpen;
  }

  // Close dropdown when clicking outside (you can add this as a directive later)
  closeProfileDropdown(): void {
    this.profileDropdownOpen = false;
  }

  // Scroll to reports section
  scrollToReports(): void {
    const reportsElement = document.querySelector('.reports-section');
    if (reportsElement) {
      reportsElement.scrollIntoView({ 
        behavior: 'smooth', 
        block: 'start' 
      });
      this.notificationService.success('Scrolled to Reports section');
    } else {
      this.notificationService.info('Reports section not found on this page');
    }
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event): void {
    const target = event.target as HTMLElement;
    if (!target.closest('.user-profile-dropdown')) {
      this.profileDropdownOpen = false;
    }
  }

  onLogoError(event: any) {
    this.logoIndex++;
    if (this.logoIndex < LOGO_PATHS.length) {
      event.target.src = LOGO_PATHS[this.logoIndex];
    }
  }

  navigateToLoanTypeManagement(): void {
    this.router.navigate(['/loan-type-management']);
  }
}
