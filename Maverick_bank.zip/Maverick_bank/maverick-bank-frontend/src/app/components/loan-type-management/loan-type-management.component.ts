import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { LoanTypeService, LoanType } from '../../services/loan-type.service';
import { NotificationService } from '../../services/notification.service';

@Component({
  selector: 'app-loan-type-management',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './loan-type-management.component.html',
  styleUrls: ['./loan-type-management.component.css']
})
export class LoanTypeManagementComponent implements OnInit {
  loanTypes: LoanType[] = [];
  filteredLoanTypes: LoanType[] = [];
  currentLoanType: LoanType | null = null;
  
  showForm = false;
  isEditing = false;
  isLoading = false;
  searchTerm = '';
  
  loanTypeForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private loanTypeService: LoanTypeService,
    private notificationService: NotificationService
  ) {
    this.loanTypeForm = this.createLoanTypeForm();
  }

  ngOnInit(): void {
    this.loadLoanTypes();
  }

  createLoanTypeForm(): FormGroup {
    return this.fb.group({
      loanName: ['', [Validators.required, Validators.minLength(3)]],
      description: ['', [Validators.required, Validators.minLength(10)]],
      interestRate: ['', [Validators.required, Validators.min(0), Validators.max(50)]],
      maxAmount: ['', [Validators.required, Validators.min(1000)]],
      maxTenureMonths: ['', [Validators.required, Validators.min(1), Validators.max(480)]], // 40 years max
      isActive: [true]
    });
  }

  loadLoanTypes(): void {
    this.isLoading = true;
    this.loanTypeService.getAllLoanTypes().subscribe({
      next: (loanTypes) => {
        this.loanTypes = loanTypes;
        this.filteredLoanTypes = loanTypes;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading loan types:', error);
        this.notificationService.error('Failed to load loan types');
        this.isLoading = false;
      }
    });
  }

  onSearch(): void {
    if (!this.searchTerm.trim()) {
      this.filteredLoanTypes = this.loanTypes;
    } else {
      this.filteredLoanTypes = this.loanTypes.filter(loanType =>
        loanType.loanName.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
        loanType.description.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    }
  }

  showAddForm(): void {
    this.showForm = true;
    this.isEditing = false;
    this.currentLoanType = null;
    this.loanTypeForm.reset();
    this.loanTypeForm.patchValue({ isActive: true });
  }

  editLoanType(loanType: LoanType): void {
    this.showForm = true;
    this.isEditing = true;
    this.currentLoanType = loanType;
    this.loanTypeForm.patchValue(loanType);
  }

  deleteLoanType(loanType: LoanType): void {
    if (confirm(`Are you sure you want to delete the loan type "${loanType.loanName}"?`)) {
      this.loanTypeService.deleteLoanType(loanType.id!).subscribe({
        next: () => {
          this.notificationService.success('Loan type deleted successfully');
          this.loadLoanTypes();
        },
        error: (error) => {
          console.error('Error deleting loan type:', error);
          this.notificationService.error('Failed to delete loan type');
        }
      });
    }
  }

  onSubmit(): void {
    if (this.loanTypeForm.valid) {
      const formData = this.loanTypeForm.value;
      
      this.isLoading = true;

      if (this.isEditing && this.currentLoanType) {
        // Update existing loan type
        const updatedLoanType = { ...formData, id: this.currentLoanType.id };
        this.loanTypeService.updateLoanType(this.currentLoanType.id!, updatedLoanType).subscribe({
          next: () => {
            this.notificationService.success('Loan type updated successfully');
            this.cancelForm();
            this.loadLoanTypes();
            this.isLoading = false;
          },
          error: (error) => {
            console.error('Error updating loan type:', error);
            this.notificationService.error('Failed to update loan type');
            this.isLoading = false;
          }
        });
      } else {
        // Create new loan type
        this.loanTypeService.createLoanType(formData).subscribe({
          next: () => {
            this.notificationService.success('Loan type created successfully');
            this.cancelForm();
            this.loadLoanTypes();
            this.isLoading = false;
          },
          error: (error) => {
            console.error('Error creating loan type:', error);
            this.notificationService.error('Failed to create loan type');
            this.isLoading = false;
          }
        });
      }
    } else {
      this.notificationService.error('Please fill all required fields correctly');
    }
  }

  cancelForm(): void {
    this.showForm = false;
    this.isEditing = false;
    this.currentLoanType = null;
    this.loanTypeForm.reset();
  }

  isFieldInvalid(fieldName: string): boolean {
    const field = this.loanTypeForm.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(fieldName: string): string {
    const field = this.loanTypeForm.get(fieldName);
    if (field && field.errors && field.touched) {
      const errors = field.errors;
      if (errors['required']) return `${fieldName} is required`;
      if (errors['minlength']) return `${fieldName} must be at least ${errors['minlength'].requiredLength} characters`;
      if (errors['min']) return `${fieldName} must be at least ${errors['min'].min}`;
      if (errors['max']) return `${fieldName} must not exceed ${errors['max'].max}`;
    }
    return '';
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }
}
