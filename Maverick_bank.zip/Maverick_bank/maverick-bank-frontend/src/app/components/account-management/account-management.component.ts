import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, RouterModule } from '@angular/router';
import { 
  AccountManagementService, 
  Account, 
  Transaction, 
  AccountRequest
} from '../../services/account-management.service';
import { BeneficiaryService, Beneficiary } from '../../services/beneficiary.service';
import { BankService, Bank, Branch } from '../../services/bank.service';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-account-management',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterModule],
  templateUrl: './account-management.component.html',
  styleUrls: ['./account-management.component.css']
})
export class AccountManagementComponent implements OnInit {
  // Data properties
  accounts: Account[] = [];
  accountRequests: AccountRequest[] = [];
  pendingAccountRequests: AccountRequest[] = []; // For employee/admin view
  selectedAccount: Account | null = null;
  transactions: Transaction[] = [];
  beneficiaries: Beneficiary[] = [];
  banks: Bank[] = [];
  branches: Branch[] = [];
  
  // UI state
  activeTab: string = 'overview'; // 'overview', 'transactions', 'new-account', 'beneficiaries', 'requests', 'employee-requests'
  isLoading = false;
  showAccountDetails = false;
  showAddBeneficiary = false;
  viewMode: string = 'customer'; // 'customer', 'employee', 'admin'
  pendingAccountSelection: { id: number; accountNumber: string } | null = null;
  
  // Transaction filters
  transactionFilter: string = 'all'; // 'all', 'last10', 'lastMonth', 'dateRange'
  dateFrom: string = '';
  dateTo: string = '';
  
  // Forms
  newAccountForm: FormGroup;
  beneficiaryForm: FormGroup;
  
  // Current user 
  currentUser: User | null = null;

  // Transaction form properties
  showTransactionForm = false;
  currentTransactionType: 'deposit' | 'withdraw' | 'transfer' | 'beneficiary-transfer' | null = null;
  transactionAmount: number | null = null;
  transactionDescription = '';
  transferToAccountId: number | null = null;
  transferToAccountNumber: string = '';
  selectedBeneficiaryId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private accountService: AccountManagementService,
    private beneficiaryService: BeneficiaryService,
    private bankService: BankService,
    private authService: AuthService
  ) {
    this.newAccountForm = this.createNewAccountForm();
    this.beneficiaryForm = this.createBeneficiaryForm();
  }

  ngOnInit(): void {
    // Check for mode parameter (employee/admin)
    this.route.queryParams.subscribe(params => {
      this.viewMode = params['mode'] || 'customer';
      if (this.viewMode === 'employee' || this.viewMode === 'admin') {
        this.activeTab = 'employee-requests';
      }
      
      // Check if an account was selected from dashboard
      if (params['accountId'] && params['accountNumber']) {
        // Load the specific account and show details
        const accountId = parseInt(params['accountId']);
        // We'll load accounts first, then select this specific one
        this.pendingAccountSelection = { id: accountId, accountNumber: params['accountNumber'] };
      }
    });

    // Get current user from auth service
    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        if (this.viewMode === 'customer') {
          this.loadUserAccounts();
          this.loadUserAccountRequests();
          this.loadBeneficiaries();
        } else if (this.viewMode === 'employee' || this.viewMode === 'admin') {
          this.loadPendingAccountRequests();
        }
        this.loadBanks();
      }
    });
  }

  private createNewAccountForm(): FormGroup {
    return this.fb.group({
      accountType: ['', Validators.required],
      ifscCode: ['', Validators.required],
      branchName: ['', Validators.required],
      branchAddress: ['', Validators.required]
    });
  }

  private createBeneficiaryForm(): FormGroup {
    return this.fb.group({
      name: ['', Validators.required],
      accountNumber: ['', Validators.required],
      bankName: ['', Validators.required],
      branchName: ['', Validators.required],
      ifscCode: ['', Validators.required]
    });
  }

  // Load user accounts - REAL API
  loadUserAccounts(): void {
    if (!this.currentUser?.id) return;
    
    this.isLoading = true;
    this.accountService.getUserAccounts(this.currentUser.id).subscribe({
      next: (accounts) => {
        this.accounts = accounts;
        this.isLoading = false;
        
        // If there's a pending account selection from dashboard, auto-select it
        if (this.pendingAccountSelection) {
          const selectedAccount = accounts.find(acc => acc.id === this.pendingAccountSelection!.id);
          if (selectedAccount) {
            this.selectAccount(selectedAccount);
          }
          this.pendingAccountSelection = null; // Clear after use
        }
      },
      error: (error) => {
        console.error('Error loading accounts:', error);
        this.isLoading = false;
      }
    });
  }

  // Load user account requests - REAL API
  loadUserAccountRequests(): void {
    if (!this.currentUser?.id) return;
    
    this.accountService.getUserAccountRequests(this.currentUser.id).subscribe({
      next: (requests) => {
        this.accountRequests = requests;
      },
      error: (error) => {
        console.error('Error loading account requests:', error);
      }
    });
  }

  // Load pending account requests (for employee/admin view) - REAL API
  loadPendingAccountRequests(): void {
    this.isLoading = true;
    this.accountService.getPendingAccountRequests().subscribe({
      next: (requests) => {
        this.pendingAccountRequests = requests;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading pending requests:', error);
        this.isLoading = false;
      }
    });
  }

  // Load beneficiaries - REAL API
  loadBeneficiaries(): void {
    if (!this.currentUser?.id) return;
    
    this.beneficiaryService.getUserBeneficiaries(this.currentUser.id).subscribe({
      next: (beneficiaries: Beneficiary[]) => {
        this.beneficiaries = beneficiaries;
      },
      error: (error: any) => {
        console.error('Error loading beneficiaries:', error);
      }
    });
  }

  // Load banks - REAL API
  loadBanks(): void {
    this.bankService.getAllBanks().subscribe({
      next: (banks: Bank[]) => {
        this.banks = banks;
      },
      error: (error: any) => {
        console.error('Error loading banks:', error);
      }
    });
  }

  // Select account to view details
  selectAccount(account: Account): void {
    this.selectedAccount = account;
    this.showAccountDetails = true;
    this.loadAccountTransactions(account.accountNumber);
  }

  // Load transactions for selected account - REAL API
  loadAccountTransactions(accountNumber: string): void {
    if (!this.selectedAccount) return;
    
    this.isLoading = true;
    
    // Use account ID instead of account number for API calls
    const accountId = this.selectedAccount.id;
    
    // Determine the filter based on transactionFilter
    let apiCall;
    
    switch (this.transactionFilter) {
      case 'last10':
        apiCall = this.accountService.getLastNTransactions(accountId, 10);
        break;
      case 'lastMonth':
        const lastMonth = new Date();
        lastMonth.setMonth(lastMonth.getMonth() - 1);
        const lastMonthStr = lastMonth.toISOString().split('T')[0];
        const todayStr = new Date().toISOString().split('T')[0];
        apiCall = this.accountService.getTransactionsByDateRange(accountId, lastMonthStr, todayStr);
        break;
      case 'dateRange':
        if (this.dateFrom && this.dateTo) {
          apiCall = this.accountService.getTransactionsByDateRange(accountId, this.dateFrom, this.dateTo);
        } else {
          apiCall = this.accountService.getAccountTransactions(accountId);
        }
        break;
      default:
        apiCall = this.accountService.getAccountTransactions(accountId);
    }

    apiCall.subscribe({
      next: (transactions) => {
        this.transactions = transactions;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading transactions:', error);
        this.isLoading = false;
      }
    });
  }

  // Filter transactions
  applyTransactionFilter(): void {
    if (this.selectedAccount) {
      this.loadAccountTransactions(this.selectedAccount.accountNumber);
    }
  }

  // Submit account opening request - REAL API
  submitAccountRequest(): void {
    if (this.newAccountForm.valid && this.currentUser?.id) {
      const formData = this.newAccountForm.value;
      
      const accountRequestData = {
        userId: this.currentUser.id,
        accountType: formData.accountType,
        ifscCode: formData.ifscCode,
        branchName: formData.branchName,
        branchAddress: formData.branchAddress
      };
      
      this.isLoading = true;
      this.accountService.submitAccountRequest(accountRequestData).subscribe({
        next: (request) => {
          console.log('Account request submitted successfully:', request);
          this.loadUserAccountRequests(); // Refresh requests
          this.newAccountForm.reset();
          this.activeTab = 'overview'; // Switch back to overview
          this.isLoading = false;
          alert('Account request submitted successfully! You will be notified once reviewed.');
        },
        error: (error) => {
          console.error('Error submitting account request:', error);
          this.isLoading = false;
          alert('Error submitting account request. Please try again.');
        }
      });
    }
  }

  // Add beneficiary - REAL API
  addBeneficiary(): void {
    if (this.beneficiaryForm.valid && this.currentUser?.id) {
      const beneficiaryData = {
        ...this.beneficiaryForm.value,
        userId: this.currentUser.id
      };
      
      this.isLoading = true;
      this.beneficiaryService.addBeneficiary(beneficiaryData).subscribe({
        next: (beneficiary: Beneficiary) => {
          console.log('Beneficiary added successfully:', beneficiary);
          this.loadBeneficiaries(); // Refresh beneficiaries
          this.beneficiaryForm.reset();
          this.showAddBeneficiary = false;
          this.isLoading = false;
          alert('Beneficiary added successfully!');
        },
        error: (error: any) => {
          console.error('Error adding beneficiary:', error);
          this.isLoading = false;
          alert('Error adding beneficiary. Please try again.');
        }
      });
    }
  }

  // Remove beneficiary - REAL API
  removeBeneficiary(beneficiaryId: number): void {
    if (confirm('Are you sure you want to remove this beneficiary?')) {
      this.isLoading = true;
      this.beneficiaryService.deleteBeneficiary(beneficiaryId).subscribe({
        next: () => {
          this.loadBeneficiaries(); // Refresh beneficiaries
          this.isLoading = false;
          alert('Beneficiary removed successfully!');
        },
        error: (error) => {
          console.error('Error removing beneficiary:', error);
          this.isLoading = false;
          alert('Error removing beneficiary. Please try again.');
        }
      });
    }
  }

  // Load branches when bank is selected - REAL API
  onBankSelected(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const bankId = target.value;
    if (bankId) {
      // Find the bank name from the ID
      const selectedBank = this.banks.find(bank => bank.id === parseInt(bankId));
      if (selectedBank) {
        this.bankService.getBranchesByBankName(selectedBank.name).subscribe({
          next: (branches: Branch[]) => {
            this.branches = branches;
            // Clear branch and IFSC when bank changes
            this.beneficiaryForm.patchValue({
              branchName: '',
              ifscCode: ''
            });
          },
          error: (error: any) => {
            console.error('Error loading branches:', error);
            this.branches = [];
          }
        });
      }
    } else {
      this.branches = [];
    }
  }

  // Load IFSC when branch is selected
  onBranchSelected(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const branchId = target.value;
    if (branchId) {
      // Find the branch from the ID
      const selectedBranch = this.branches.find(b => b.id === parseInt(branchId));
      if (selectedBranch) {
        this.beneficiaryForm.patchValue({
          branchName: selectedBranch.name,
          ifscCode: selectedBranch.ifscCode
        });
      }
    } else {
      this.beneficiaryForm.patchValue({
        branchName: '',
        ifscCode: ''
      });
    }
  }

  // Request account closure
  requestAccountClosure(account: Account): void {
    if (confirm(`Are you sure you want to request closure for account ${account.accountNumber}?`)) {
      // TODO: Replace with real API call
      // this.accountService.requestAccountClosure(account.id).subscribe(...)
      console.log('Requesting closure for account:', account.id);
    }
  }

  // Approve account request (Employee/Admin functionality)
  approveAccountRequest(requestId: number): void {
    if (!this.currentUser) {
      alert('User not authenticated. Please login again.');
      return;
    }
    
    if (confirm('Are you sure you want to approve this account request?')) {
      const comments = prompt('Please provide approval comments (optional):') || 'Approved';
      this.isLoading = true;
      this.accountService.approveAccountRequest(requestId, this.currentUser.id, comments).subscribe({
        next: () => {
          alert('Account request approved successfully!');
          this.loadPendingAccountRequests(); // Refresh the list
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error approving account request:', error);
          alert('Error approving account request. Please try again.');
          this.isLoading = false;
        }
      });
    }
  }

  // Reject account request (Employee/Admin functionality)
  rejectAccountRequest(requestId: number): void {
    if (!this.currentUser) {
      alert('User not authenticated. Please login again.');
      return;
    }
    
    const comments = prompt('Please provide a reason for rejection:');
    if (comments && comments.trim() !== '') {
      this.isLoading = true;
      this.accountService.rejectAccountRequest(requestId, this.currentUser.id, comments.trim()).subscribe({
        next: () => {
          alert('Account request rejected successfully!');
          this.loadPendingAccountRequests(); // Refresh the list
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error rejecting account request:', error);
          alert('Error rejecting account request. Please try again.');
          this.isLoading = false;
        }
      });
    }
  }

  // Check if current user has employee/admin permissions
  canApproveRequests(): boolean {
    return this.viewMode === 'employee' || this.viewMode === 'admin';
  }

  // Navigation methods
  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  goBackToAccounts(): void {
    this.showAccountDetails = false;
    this.selectedAccount = null;
  }

  // Utility methods
  calculateAge(dateOfBirth: string): number {
    const dob = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const monthDiff = today.getMonth() - dob.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    
    return age;
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getTotalBalance(): number {
    return this.accounts.reduce((total, account) => total + account.balance, 0);
  }

  getActiveAccountsCount(): number {
    return this.accounts.filter(account => account.isActive).length;
  }

  // Transaction form methods
  showDepositForm(): void {
    this.currentTransactionType = 'deposit';
    this.showTransactionForm = true;
    this.resetTransactionForm();
  }

  showWithdrawForm(): void {
    this.currentTransactionType = 'withdraw';
    this.showTransactionForm = true;
    this.resetTransactionForm();
  }

  showTransferForm(): void {
    this.currentTransactionType = 'transfer';
    this.showTransactionForm = true;
    this.resetTransactionForm();
  }

  showBeneficiaryTransferForm(): void {
    this.currentTransactionType = 'beneficiary-transfer';
    this.showTransactionForm = true;
    this.resetTransactionForm();
  }

  cancelTransaction(): void {
    this.showTransactionForm = false;
    this.currentTransactionType = null;
    this.resetTransactionForm();
  }

  private resetTransactionForm(): void {
    this.transactionAmount = null;
    this.transactionDescription = '';
    this.transferToAccountId = null;
    this.transferToAccountNumber = '';
    this.selectedBeneficiaryId = null;
  }

  // Transaction execution methods
  executeDeposit(): void {
    if (!this.selectedAccount || !this.transactionAmount || this.transactionAmount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    this.isLoading = true;
    this.accountService.deposit(
      this.selectedAccount.id, 
      this.transactionAmount, 
      this.transactionDescription || 'Deposit'
    ).subscribe({
      next: (transaction) => {
        alert('Deposit successful!');
        this.refreshAccountData();
        this.cancelTransaction();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Deposit failed:', error);
        alert('Deposit failed. Please try again.');
        this.isLoading = false;
      }
    });
  }

  executeWithdraw(): void {
    if (!this.selectedAccount || !this.transactionAmount || this.transactionAmount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    if (this.transactionAmount > this.selectedAccount.balance) {
      alert('Insufficient balance');
      return;
    }

    this.isLoading = true;
    this.accountService.withdraw(
      this.selectedAccount.id, 
      this.transactionAmount, 
      this.transactionDescription || 'Withdrawal'
    ).subscribe({
      next: (transaction) => {
        alert('Withdrawal successful!');
        this.refreshAccountData();
        this.cancelTransaction();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Withdrawal failed:', error);
        alert('Withdrawal failed. Please try again.');
        this.isLoading = false;
      }
    });
  }

  executeTransfer(): void {
    if (!this.selectedAccount || !this.transactionAmount || !this.transferToAccountNumber || this.transactionAmount <= 0) {
      alert('Please fill all required fields with valid values');
      return;
    }

    if (this.transactionAmount > this.selectedAccount.balance) {
      alert('Insufficient balance');
      return;
    }

    this.isLoading = true;
    this.accountService.transferByAccountNumber(
      this.selectedAccount.id, 
      this.transferToAccountNumber, 
      this.transactionAmount, 
      this.transactionDescription || 'Fund Transfer Within Bank'
    ).subscribe({
      next: (transaction) => {
        alert('Transfer successful!');
        this.refreshAccountData();
        this.cancelTransaction();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Transfer failed:', error);
        alert('Transfer failed. Please check the account number and try again.');
        this.isLoading = false;
      }
    });
  }

  executeBeneficiaryTransfer(): void {
    if (!this.selectedAccount || !this.transactionAmount || !this.selectedBeneficiaryId || this.transactionAmount <= 0) {
      alert('Please fill all required fields with valid values');
      return;
    }

    if (this.transactionAmount > this.selectedAccount.balance) {
      alert('Insufficient balance');
      return;
    }

    this.isLoading = true;
    this.accountService.transferToBeneficiary(
      this.selectedAccount.id, 
      this.selectedBeneficiaryId, 
      this.transactionAmount, 
      this.transactionDescription || 'Transfer to Beneficiary'
    ).subscribe({
      next: (transaction) => {
        alert('Transfer to beneficiary successful!');
        this.refreshAccountData();
        this.cancelTransaction();
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Beneficiary transfer failed:', error);
        alert('Beneficiary transfer failed. Please try again.');
        this.isLoading = false;
      }
    });
  }

  private refreshAccountData(): void {
    if (this.selectedAccount && this.currentUser) {
      // Refresh the account balance
      this.loadUserAccounts();
      // Refresh transactions
      this.loadAccountTransactions(this.selectedAccount.accountNumber);
    }
  }
}
