import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportService } from '../../services/report.service';
import { AuthService } from '../../services/auth.service';
import { NotificationService } from '../../services/notification.service';

interface AccountStatement {
  accountNumber: string;
  accountType: string;
  balance: number;
  transactions: TransactionHistory[];
  statementPeriod: string;
}

interface TransactionHistory {
  id: number;
  amount: number;
  transactionType: string;
  description: string;
  timestamp: string;
  balance?: number;
}

@Component({
  selector: 'app-customer-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="customer-reports-container">      
      <!-- Debug Info Panel -->
      <div class="debug-panel" *ngIf="debugInfo.lastError || debugInfo.apiCalls.length > 0">
        <h4>🔧 Debug Information</h4>
        <div *ngIf="debugInfo.userId">
          <strong>User ID:</strong> {{debugInfo.userId}}
        </div>
        <div *ngIf="debugInfo.dataLoaded">
          <strong>Data Status:</strong> ✅ Loaded
        </div>
        <div *ngIf="debugInfo.apiCalls.length > 0">
          <strong>API Calls:</strong> {{debugInfo.apiCalls.join(', ')}}
        </div>
        <div *ngIf="debugInfo.lastError" class="error-msg">
          <strong>Last Error:</strong> {{debugInfo.lastError}}
        </div>
      </div>
      
      <!-- Header -->
      <div class="reports-header">
        <h2>📊 My Account Reports</h2>
        <p>Generate and download your account statements and transaction history</p>
      </div>

      <!-- Report Options -->
      <div class="report-options">
        <!-- Account Statement Report -->
        <div class="report-card">
          <div class="report-card-header">
            <div class="report-icon">📋</div>
            <div class="report-info">
              <h3>Account Statement</h3>
              <p>Generate detailed account statements with balance and transaction summary</p>
            </div>
          </div>
          
          <div class="report-controls">
            <div class="form-group" *ngIf="userAccounts.length > 0">
              <label for="accountSelect">Select Account:</label>
              <select id="accountSelect" [(ngModel)]="selectedAccountId" class="form-select">
                <option *ngFor="let account of userAccounts" [value]="account.id">
                  {{account.accountNumber}} - {{account.accountType}} (₹{{account.balance | number}})
                </option>
              </select>
            </div>
            
            <div class="form-group">
              <label for="statementPeriod">Statement Period:</label>
              <select id="statementPeriod" [(ngModel)]="selectedPeriod" class="form-select">
                <option value="1month">Last 1 Month</option>
                <option value="3months">Last 3 Months</option>
                <option value="6months">Last 6 Months</option>
                <option value="1year">Last 1 Year</option>
              </select>
            </div>
            
            <div class="action-buttons">
              <button 
                class="btn btn-primary" 
                (click)="generateAccountStatement()" 
                [disabled]="isLoading || userAccounts.length === 0">
                <span class="btn-icon">📊</span>
                {{ isLoading ? 'Generating...' : 'Generate Statement' }}
              </button>
              
              <button 
                class="btn btn-secondary" 
                (click)="downloadAccountStatement()" 
                [disabled]="!accountStatement || isLoading">
                <span class="btn-icon">⬇️</span>
                Download PDF
              </button>
            </div>
          </div>
        </div>

        <!-- Transaction History Report -->
        <div class="report-card">
          <div class="report-card-header">
            <div class="report-icon">💳</div>
            <div class="report-info">
              <h3>Transaction History</h3>
              <p>View and export your complete transaction history with filters</p>
            </div>
          </div>
          
          <div class="report-controls">
            <div class="form-group">
              <label for="transactionType">Transaction Type:</label>
              <select id="transactionType" [(ngModel)]="selectedTransactionType" class="form-select">
                <option value="">All Transactions</option>
                <option value="CREDIT">Credit Only</option>
                <option value="DEBIT">Debit Only</option>
              </select>
            </div>
            
            <div class="action-buttons">
              <button 
                class="btn btn-primary" 
                (click)="generateTransactionHistory()" 
                [disabled]="isLoading">
                <span class="btn-icon">🔍</span>
                {{ isLoading ? 'Loading...' : 'Load Transactions' }}
              </button>
              
              <button 
                class="btn btn-secondary" 
                (click)="exportTransactionsCSV()" 
                [disabled]="transactionHistory.length === 0 || isLoading">
                <span class="btn-icon">📤</span>
                Export CSV
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Account Statement Display -->
      <div *ngIf="accountStatement" class="statement-display">
        <div class="statement-header">
          <h3>Account Statement</h3>
          <div class="statement-meta">
            <span>Account: {{accountStatement.accountNumber}}</span>
            <span>Period: {{accountStatement.statementPeriod}}</span>
            <span>Generated: {{getCurrentDate()}}</span>
          </div>
        </div>
        
        <div class="statement-summary">
          <div class="summary-item">
            <span class="label">Account Type:</span>
            <span class="value">{{accountStatement.accountType}}</span>
          </div>
          <div class="summary-item">
            <span class="label">Current Balance:</span>
            <span class="value balance">₹{{accountStatement.balance | number}}</span>
          </div>
          <div class="summary-item">
            <span class="label">Total Transactions:</span>
            <span class="value">{{accountStatement.transactions.length}}</span>
          </div>
        </div>
        
        <div class="transactions-table">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Balance</th>
              </tr>
            </thead>
            <tbody>
              <tr *ngFor="let transaction of accountStatement.transactions" 
                  [class]="transaction.transactionType.toLowerCase()">
                <td>{{formatDate(transaction.timestamp)}}</td>
                <td>{{transaction.description}}</td>
                <td>
                  <span class="transaction-type" [class]="transaction.transactionType.toLowerCase()">
                    {{transaction.transactionType}}
                  </span>
                </td>
                <td class="amount" [class]="transaction.transactionType.toLowerCase()">
                  {{transaction.transactionType === 'CREDIT' ? '+' : '-'}}₹{{transaction.amount | number}}
                </td>
                <td>₹{{transaction.balance | number}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Transaction History Display -->
      <div *ngIf="transactionHistory.length > 0" class="transaction-history-display">
        <div class="history-header">
          <h3>Transaction History</h3>
          <span class="transaction-count">{{transactionHistory.length}} transactions found</span>
        </div>
        
        <div class="transactions-grid">
          <div *ngFor="let transaction of transactionHistory" class="transaction-card" 
               [class]="transaction.transactionType.toLowerCase()">
            <div class="transaction-date">{{formatDate(transaction.timestamp)}}</div>
            <div class="transaction-details">
              <h4>{{transaction.description}}</h4>
              <span class="transaction-type">{{transaction.transactionType}}</span>
            </div>
            <div class="transaction-amount" [class]="transaction.transactionType.toLowerCase()">
              {{transaction.transactionType === 'CREDIT' ? '+' : '-'}}₹{{transaction.amount | number}}
            </div>
          </div>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="isLoading" class="loading-state">
        <div class="loading-spinner"></div>
        <p>Loading report data...</p>
      </div>

      <!-- No Data State -->
      <div *ngIf="!isLoading && userAccounts.length === 0" class="no-data-state">
        <div class="no-data-icon">🏦</div>
        <h3>No Accounts Found</h3>
        <p>You don't have any accounts to generate reports for.</p>
      </div>
    </div>
  `,
  styleUrls: ['./customer-reports.component.css']
})
export class CustomerReportsComponent implements OnInit {
  accountStatement: AccountStatement | null = null;
  transactionHistory: TransactionHistory[] = [];
  userAccounts: any[] = [];
  
  selectedPeriod = '1month';
  selectedAccountId = '';
  selectedTransactionType = '';
  isLoading = false;

  // Debug properties
  debugInfo = {
    userId: null as number | null,
    apiCalls: [] as string[],
    lastError: null as string | null,
    dataLoaded: false
  };

  constructor(
    private reportService: ReportService,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    console.log('🔄 CustomerReports: Component initializing...');
    this.loadUserData();
  }

  loadUserData(): void {
    this.authService.user$.subscribe(user => {
      if (user && user.id) {
        this.debugInfo.userId = user.id;
        console.log(`✅ CustomerReports: User loaded - ID: ${user.id}, Name: ${user.name}`);
        this.loadUserAccounts();
      } else {
        console.log('❌ CustomerReports: No user found');
        this.debugInfo.lastError = 'No user found';
        this.notificationService.error('User not found');
        
        // Use mock data for demo
        this.loadMockData();
      }
    });
  }

  loadUserAccounts(): void {
    if (!this.debugInfo.userId) return;
    
    console.log(`🔄 CustomerReports: Loading accounts for user ${this.debugInfo.userId}...`);
    this.isLoading = true;
    this.debugInfo.apiCalls.push(`getUserAccounts(${this.debugInfo.userId})`);
    
    this.reportService.getUserAccounts(this.debugInfo.userId).subscribe({
      next: (accounts) => {
        this.userAccounts = accounts;
        console.log(`✅ CustomerReports: Loaded ${accounts.length} accounts:`, accounts);
        this.debugInfo.dataLoaded = true;
        if (accounts.length > 0) {
          this.selectedAccountId = accounts[0].id.toString();
          this.generateTransactionHistory();
        }
        this.isLoading = false;
        this.notificationService.success(`Loaded ${accounts.length} accounts`);
      },
      error: (error) => {
        console.error('❌ CustomerReports: Error loading accounts:', error);
        this.debugInfo.lastError = `Error loading accounts: ${error.message}`;
        this.isLoading = false;
        this.notificationService.error('Failed to load accounts - using demo data');
        
        // Use mock data for demo
        this.loadMockData();
      }
    });
  }

  loadMockData(): void {
    console.log('🔄 CustomerReports: Loading mock data for demo...');
    this.userAccounts = [
      { id: 1, accountNumber: 'ACC001234', accountType: 'SAVINGS', balance: 25000 },
      { id: 2, accountNumber: 'ACC001235', accountType: 'CURRENT', balance: 15000 }
    ];
    this.selectedAccountId = this.userAccounts[0].id.toString();
    this.generateTransactionHistory();
    this.debugInfo.dataLoaded = true;
    console.log('✅ CustomerReports: Mock data loaded');
  }

  generateAccountStatement(): void {
    console.log('🔄 CustomerReports: Generating account statement...');
    this.isLoading = true;
    
    if (!this.selectedAccountId) {
      this.notificationService.error('Please select an account');
      this.isLoading = false;
      return;
    }

    const accountId = parseInt(this.selectedAccountId);
    console.log(`🔄 CustomerReports: Fetching statement for account ID: ${accountId}`);
    this.debugInfo.apiCalls.push(`getAccountStatement(${accountId})`);
    
    // Get account details first
    const selectedAccount = this.userAccounts.find(acc => acc.id === accountId);
    if (!selectedAccount) {
      this.notificationService.error('Selected account not found');
      this.isLoading = false;
      return;
    }

    // Get account statement with date range
    const { startDate, endDate } = this.getDateRange();
    this.reportService.getAccountStatement(accountId, startDate, endDate).subscribe({
      next: (transactions) => {
        console.log(`✅ CustomerReports: Loaded ${transactions.length} transactions for statement`);
        
        this.accountStatement = {
          accountNumber: selectedAccount.accountNumber,
          accountType: selectedAccount.accountType,
          balance: selectedAccount.balance,
          transactions: transactions,
          statementPeriod: this.getPeriodLabel()
        };
        
        this.isLoading = false;
        this.notificationService.success(`Account statement generated with ${transactions.length} transactions`);
      },
      error: (error) => {
        console.error('❌ CustomerReports: Error generating statement:', error);
        this.debugInfo.lastError = `Error generating statement: ${error.message}`;
        this.isLoading = false;
        this.notificationService.error('Failed to generate statement - using demo data');
        
        // Generate mock statement
        this.generateMockStatement(selectedAccount);
      }
    });
  }

  generateMockStatement(account: any): void {
    console.log('🔄 CustomerReports: Generating mock statement...');
    const mockTransactions = [
      {
        id: 1,
        amount: 5000,
        transactionType: 'CREDIT',
        description: 'Salary Deposit',
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        balance: account.balance
      },
      {
        id: 2,
        amount: 1200,
        transactionType: 'DEBIT',
        description: 'ATM Withdrawal',
        timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        balance: account.balance - 1200
      },
      {
        id: 3,
        amount: 850,
        transactionType: 'DEBIT',
        description: 'Online Shopping',
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        balance: account.balance - 2050
      }
    ];

    this.accountStatement = {
      accountNumber: account.accountNumber,
      accountType: account.accountType,
      balance: account.balance,
      transactions: mockTransactions,
      statementPeriod: this.getPeriodLabel()
    };
    
    console.log('✅ CustomerReports: Mock statement generated');
    this.notificationService.info('Demo statement generated with sample data');
  }

  generateTransactionHistory(): void {
    console.log('🔄 CustomerReports: Loading transaction history...');
    this.isLoading = true;
    
    if (this.debugInfo.userId) {
      this.debugInfo.apiCalls.push(`getUserTransactions(${this.debugInfo.userId})`);
      
      this.reportService.getUserTransactions(this.debugInfo.userId).subscribe({
        next: (transactions) => {
          let filteredTransactions = transactions;
          
          // Apply transaction type filter
          if (this.selectedTransactionType) {
            filteredTransactions = transactions.filter(t => 
              t.transactionType === this.selectedTransactionType
            );
          }
          
          this.transactionHistory = filteredTransactions.slice(0, 50); // Limit to 50 recent
          console.log(`✅ CustomerReports: Loaded ${this.transactionHistory.length} transactions`);
          this.isLoading = false;
          this.notificationService.success(`Loaded ${this.transactionHistory.length} transactions`);
        },
        error: (error) => {
          console.error('❌ CustomerReports: Error loading transactions:', error);
          this.debugInfo.lastError = `Error loading transactions: ${error.message}`;
          this.isLoading = false;
          this.notificationService.error('Failed to load transactions - using demo data');
          
          // Use mock transactions
          this.generateMockTransactions();
        }
      });
    } else {
      this.generateMockTransactions();
    }
  }

  generateMockTransactions(): void {
    console.log('🔄 CustomerReports: Generating mock transactions...');
    this.transactionHistory = [
      {
        id: 1,
        amount: 5000,
        transactionType: 'CREDIT',
        description: 'Salary Deposit',
        timestamp: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 2,
        amount: 1200,
        transactionType: 'DEBIT',
        description: 'ATM Withdrawal',
        timestamp: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 3,
        amount: 850,
        transactionType: 'DEBIT',
        description: 'Online Shopping',
        timestamp: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: 4,
        amount: 2500,
        transactionType: 'CREDIT',
        description: 'Transfer from John',
        timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];
    
    // Apply filter if needed
    if (this.selectedTransactionType) {
      this.transactionHistory = this.transactionHistory.filter(t => 
        t.transactionType === this.selectedTransactionType
      );
    }
    
    this.isLoading = false;
    console.log('✅ CustomerReports: Mock transactions generated');
    this.notificationService.info(`Demo transactions loaded (${this.transactionHistory.length} items)`);
  }

  downloadAccountStatement(): void {
    if (!this.accountStatement) return;
    
    console.log('🔄 CustomerReports: Downloading account statement...');
    this.notificationService.info('Preparing download...');
    
    const statementText = this.generateStatementText();
    const blob = new Blob([statementText], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `account-statement-${this.accountStatement.accountNumber}-${Date.now()}.txt`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    this.notificationService.success('Account statement downloaded successfully');
  }

  exportTransactionsCSV(): void {
    if (this.transactionHistory.length === 0) return;
    
    console.log('🔄 CustomerReports: Exporting transactions to CSV...');
    this.notificationService.info('Preparing CSV export...');
    
    const headers = ['Date', 'Description', 'Type', 'Amount'];
    const csvContent = [
      headers.join(','),
      ...this.transactionHistory.map(t => [
        this.formatDate(t.timestamp),
        `"${t.description}"`,
        t.transactionType,
        t.amount
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `transaction-history-${Date.now()}.csv`;
    link.click();
    window.URL.revokeObjectURL(url);
    
    this.notificationService.success('Transaction history exported successfully');
  }

  getDateRange(): { startDate: string, endDate: string } {
    const endDate = new Date();
    const startDate = new Date();
    
    switch (this.selectedPeriod) {
      case '1month':
        startDate.setMonth(startDate.getMonth() - 1);
        break;
      case '3months':
        startDate.setMonth(startDate.getMonth() - 3);
        break;
      case '6months':
        startDate.setMonth(startDate.getMonth() - 6);
        break;
      case '1year':
        startDate.setFullYear(startDate.getFullYear() - 1);
        break;
    }
    
    return {
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0]
    };
  }

  getPeriodLabel(): string {
    switch (this.selectedPeriod) {
      case '1month':
        return 'Last 1 Month';
      case '3months':
        return 'Last 3 Months';
      case '6months':
        return 'Last 6 Months';
      case '1year':
        return 'Last 1 Year';
      default:
        return 'Last 1 Month';
    }
  }

  generateStatementText(): string {
    if (!this.accountStatement) return '';
    
    const statement = this.accountStatement;
    let text = `ACCOUNT STATEMENT\n`;
    text += `================\n\n`;
    text += `Account Number: ${statement.accountNumber}\n`;
    text += `Account Type: ${statement.accountType}\n`;
    text += `Statement Period: ${statement.statementPeriod}\n`;
    text += `Current Balance: ₹${statement.balance.toLocaleString()}\n`;
    text += `Generated On: ${this.getCurrentDate()}\n\n`;
    
    text += `TRANSACTION DETAILS\n`;
    text += `===================\n\n`;
    
    statement.transactions.forEach(t => {
      text += `${this.formatDate(t.timestamp)} | ${t.description} | ${t.transactionType} | ₹${t.amount.toLocaleString()}\n`;
    });
    
    return text;
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: '2-digit'
    });
  }

  getCurrentDate(): string {
    return new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'long',
      day: '2-digit'
    });
  }
}
