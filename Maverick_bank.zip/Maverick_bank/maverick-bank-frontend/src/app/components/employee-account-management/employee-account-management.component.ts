import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { 
  AccountManagementService, 
  Account, 
  AccountRequest
} from '../../services/account-management.service';
import { BankService, Bank, Branch } from '../../services/bank.service';
import { AuthService, User } from '../../services/auth.service';

@Component({
  selector: 'app-employee-account-management',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './employee-account-management.component.html',
  styleUrls: ['./employee-account-management.component.css']
})
export class EmployeeAccountManagementComponent implements OnInit {
  // Data properties - Only employee/admin relevant
  pendingAccountRequests: AccountRequest[] = [];
  banks: Bank[] = [];
  branches: Branch[] = [];
  
  // UI state
  activeTab: string = 'pending-requests'; // 'pending-requests', 'create-account'
  isLoading = false;
  isProcessingRequest = false;
  
  // Forms
  createAccountForm: FormGroup;
  
  // Current user 
  currentUser: User | null = null;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private accountService: AccountManagementService,
    private bankService: BankService,
    private authService: AuthService
  ) {
    this.createAccountForm = this.createAccountFormGroup();
  }

  ngOnInit(): void {
    // Get current user from auth service
    this.authService.user$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        // Check if user has employee/admin role
        if (!this.hasEmployeeAccess()) {
          this.router.navigate(['/dashboard']);
          return;
        }
        
        this.loadPendingAccountRequests();
        this.loadBanks();
      }
    });
  }

  private hasEmployeeAccess(): boolean {
    // Check if user has employee or admin role
    return this.currentUser?.roles?.some(role => 
      role.toLowerCase() === 'employee' || role.toLowerCase() === 'admin'
    ) || false;
  }

  private createAccountFormGroup(): FormGroup {
    return this.fb.group({
      userId: ['', [Validators.required, Validators.min(1)]],
      accountType: ['SAVINGS', Validators.required],
      ifscCode: ['', Validators.required],
      branchName: ['', Validators.required],
      branchAddress: ['', Validators.required],
      initialDeposit: [0, [Validators.required, Validators.min(500)]]
    });
  }

  // Employee/Admin Functions

  // Load pending account requests - REAL API
  loadPendingAccountRequests(): void {
    this.isLoading = true;
    this.accountService.getPendingAccountRequests().subscribe({
      next: (requests: AccountRequest[]) => {
        this.pendingAccountRequests = requests;
        this.isLoading = false;
      },
      error: (error: any) => {
        console.error('Error loading pending requests:', error);
        this.isLoading = false;
        // Fallback to empty array instead of mock data
        this.pendingAccountRequests = [];
      }
    });
  }

  // Load banks - REAL API
  loadBanks(): void {
    this.bankService.getAllBanks().subscribe({
      next: (banks: Bank[]) => {
        this.banks = banks;
      },
      error: (error: any) => {
        console.error('Error loading banks:', error);
        this.banks = [];
      }
    });
  }

  // Load branches by bank - REAL API
  onBankChange(event: any): void {
    const target = event.target as HTMLSelectElement;
    const bankId = target.value;
    if (bankId) {
      const selectedBank = this.banks.find(bank => bank.id === parseInt(bankId));
      if (selectedBank) {
        this.bankService.getBranchesByBankName(selectedBank.name).subscribe({
          next: (branches: Branch[]) => {
            this.branches = branches;
            // Clear branch selection when bank changes
            this.createAccountForm.patchValue({
              branchName: '',
              branchAddress: '',
              ifscCode: ''
            });
          },
          error: (error: any) => {
            console.error('Error loading branches:', error);
            this.branches = [];
          }
        });
      }
    }
  }

  // Auto-fill branch details when branch is selected
  onBranchChange(event: any): void {
    const target = event.target as HTMLSelectElement;
    const branchId = target.value;
    if (branchId) {
      const selectedBranch = this.branches.find(branch => branch.id === parseInt(branchId));
      if (selectedBranch) {
        this.createAccountForm.patchValue({
          branchName: selectedBranch.name,
          branchAddress: selectedBranch.address,
          ifscCode: selectedBranch.ifscCode
        });
      }
    }
  }

  // Approve account request - REAL API
  approveRequest(request: AccountRequest): void {
    if (this.isProcessingRequest) return;
    
    if (!this.currentUser) {
      alert('User not authenticated. Please login again.');
      return;
    }
    
    const comments = prompt('Please provide approval comments (optional):') || 'Approved';
    
    if (confirm(`Are you sure you want to approve the account request for ${request.user.name}?`)) {
      this.isProcessingRequest = true;
      this.accountService.approveAccountRequest(request.id, this.currentUser.id, comments).subscribe({
        next: (response: any) => {
          console.log('Request approved successfully:', response);
          this.loadPendingAccountRequests(); // Refresh the list
          this.isProcessingRequest = false;
          alert('Account request approved successfully!');
        },
        error: (error: any) => {
          console.error('Error approving request:', error);
          this.isProcessingRequest = false;
          alert('Error approving request. Please try again.');
        }
      });
    }
  }

  // Reject account request - REAL API
  rejectRequest(request: AccountRequest): void {
    if (this.isProcessingRequest) return;
    
    if (!this.currentUser) {
      alert('User not authenticated. Please login again.');
      return;
    }
    
    const comments = prompt('Please provide a reason for rejection:');
    if (comments !== null && comments.trim() !== '') {
      this.isProcessingRequest = true;
      this.accountService.rejectAccountRequest(request.id, this.currentUser.id, comments.trim()).subscribe({
        next: (response: any) => {
          console.log('Request rejected successfully:', response);
          this.loadPendingAccountRequests(); // Refresh the list
          this.isProcessingRequest = false;
          alert('Account request rejected successfully!');
        },
        error: (error: any) => {
          console.error('Error rejecting request:', error);
          this.isProcessingRequest = false;
          alert('Error rejecting request. Please try again.');
        }
      });
    }
  }

  // Create account directly (for employees/admins) - REAL API
  createAccountDirectly(): void {
    if (this.createAccountForm.valid && !this.isLoading) {
      this.isLoading = true;
      
      const accountData = {
        ...this.createAccountForm.value
      };
      
      this.accountService.openAccountDirectly(accountData).subscribe({
        next: (account: Account) => {
          console.log('Account created successfully:', account);
          this.createAccountForm.reset();
          this.createAccountForm.patchValue({ accountType: 'SAVINGS', initialDeposit: 0 });
          this.isLoading = false;
          alert(`Account created successfully! Account Number: ${account.accountNumber}`);
        },
        error: (error: any) => {
          console.error('Error creating account:', error);
          this.isLoading = false;
          alert('Error creating account. Please try again.');
        }
      });
    } else {
      alert('Please fill all required fields correctly.');
    }
  }

  // UI Navigation
  switchTab(tab: string): void {
    this.activeTab = tab;
  }

  // Utility functions
  formatDate(date: Date | string): string {
    return new Date(date).toLocaleDateString();
  }

  formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(amount);
  }

  getStatusBadgeClass(status: string): string {
    switch (status.toLowerCase()) {
      case 'pending': return 'status-badge pending';
      case 'approved': return 'status-badge approved';
      case 'rejected': return 'status-badge rejected';
      default: return 'status-badge';
    }
  }
}
