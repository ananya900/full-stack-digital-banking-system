import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { UserManagementService, UserDto, Role, CreateUserRequest, UpdateUserRequest } from '../../services/user-management.service';
import { NotificationService } from '../../services/notification.service';
import { NotificationComponent } from '../notifications/notification.component';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FormsModule, NotificationComponent],
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})
export class UserManagementComponent implements OnInit {
  users: UserDto[] = [];
  filteredUsers: UserDto[] = [];
  roles: Role[] = [];
  userStatistics: any = {};
  
  searchTerm: string = '';
  roleFilter: string = '';
  statusFilter: string = '';
  selectedUser: UserDto | null = null;
  
  // Modal states
  showCreateModal = false;
  showEditModal = false;
  showDeleteModal = false;
  
  createUserForm: FormGroup;
  editUserForm: FormGroup;
  resetPasswordForm: FormGroup;
  
  isLoading = false;
  selectedDashboard = 'ALL'; // 'ALL', 'CUSTOMER', 'EMPLOYEE', 'ADMIN'
  selectedRoleIds: Set<number> = new Set();

  constructor(
    private userManagementService: UserManagementService,
    private notificationService: NotificationService,
    private fb: FormBuilder
  ) {
    this.createUserForm = this.createForm();
    this.editUserForm = this.createEditForm(); // Use separate edit form
    this.resetPasswordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]]
    }, { validators: this.passwordMatchValidator });
  }

  ngOnInit(): void {
    this.loadUsers();
    this.loadRoles();
    this.loadStatistics();
  }

  // Form creation
  private createForm(): FormGroup {
    return this.fb.group({
      username: ['', [Validators.required, Validators.minLength(3)]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      address: ['', [Validators.required]],
      dateOfBirth: ['', [Validators.required]],
      aadharNumber: ['', [Validators.required, Validators.pattern('^[0-9]{12}$')]],
      panNumber: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
      gender: ['', [Validators.required]],
      roleIds: [[3]], // Default to CUSTOMER role (ID 3)
      isActive: [true]
    });
  }

  // Edit form creation (without username and password requirements)
  private createEditForm(): FormGroup {
    return this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.email]],
      contactNumber: ['', [Validators.required, Validators.pattern('^[0-9]{10}$')]],
      address: ['', [Validators.required]],
      dateOfBirth: ['', [Validators.required]],
      aadharNumber: ['', [Validators.required, Validators.pattern('^[0-9]{12}$')]],
      panNumber: ['', [Validators.required, Validators.pattern('^[A-Z]{5}[0-9]{4}[A-Z]{1}$')]],
      gender: ['', [Validators.required]],
      roleIds: [[]], // Empty array for edit
      isActive: [true]
    });
  }

  private passwordMatchValidator(form: FormGroup) {
    const password = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return password === confirmPassword ? null : { passwordMismatch: true };
  }

  // Data loading methods
  loadUsers(): void {
    console.log('Loading users...');
    this.isLoading = true;
    this.userManagementService.getAllUsers().subscribe({
      next: (users) => {
        console.log('Users loaded successfully:', users);
        this.users = users;
        this.filteredUsers = users;
        this.isLoading = false;
      },
      error: (error) => {
        console.error('Error loading users:', error);
        console.error('Error details:', {
          status: error.status,
          statusText: error.statusText,
          message: error.message,
          url: error.url
        });
        this.notificationService.error(`Failed to load users: ${error.status} ${error.statusText}`);
        this.isLoading = false;
      }
    });
  }

  loadRoles(): void {
    console.log('Loading roles...');
    this.userManagementService.getAllRoles().subscribe({
      next: (roles) => {
        console.log('Roles loaded successfully:', roles);
        this.roles = roles;
      },
      error: (error) => {
        console.error('Error loading roles:', error);
        console.error('Error details:', {
          status: error.status,
          statusText: error.statusText,
          message: error.message,
          url: error.url
        });
        this.notificationService.error(`Failed to load roles: ${error.status} ${error.statusText}`);
      }
    });
  }

  loadStatistics(): void {
    this.userManagementService.getUserStatistics().subscribe({
      next: (stats) => {
        this.userStatistics = stats;
      },
      error: (error) => {
        console.error('Error loading statistics:', error);
      }
    });
  }

  // Search functionality
  onSearch(): void {
    if (this.searchTerm.trim()) {
      this.userManagementService.searchUsers(this.searchTerm).subscribe({
        next: (users) => {
          this.filteredUsers = users;
          this.applyFilters();
        },
        error: (error) => {
          console.error('Error searching users:', error);
          this.notificationService.error('Search failed');
          // Fallback to local filtering
          this.applyLocalFilters();
        }
      });
    } else {
      this.filteredUsers = this.users;
      this.applyFilters();
    }
  }

  // Enhanced filtering functionality
  applyFilters(): void {
    let filtered = this.searchTerm.trim() ? this.filteredUsers : this.users;
    
    // Apply role filter
    if (this.roleFilter) {
      filtered = filtered.filter(user => 
        user.roles.some(role => role.name === this.roleFilter)
      );
    }
    
    // Apply status filter
    if (this.statusFilter) {
      const isActive = this.statusFilter === 'active';
      filtered = filtered.filter(user => user.isActive === isActive);
    }
    
    this.filteredUsers = filtered;
  }

  // Local filtering fallback
  applyLocalFilters(): void {
    let filtered = this.users;
    
    // Apply search term locally
    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();
      filtered = filtered.filter(user => 
        user.name.toLowerCase().includes(term) ||
        user.username.toLowerCase().includes(term) ||
        user.email.toLowerCase().includes(term)
      );
    }
    
    // Apply role filter
    if (this.roleFilter) {
      filtered = filtered.filter(user => 
        user.roles.some(role => role.name === this.roleFilter)
      );
    }
    
    // Apply status filter
    if (this.statusFilter) {
      const isActive = this.statusFilter === 'active';
      filtered = filtered.filter(user => user.isActive === isActive);
    }
    
    this.filteredUsers = filtered;
  }

  // Clear all filters
  clearFilters(): void {
    this.searchTerm = '';
    this.roleFilter = '';
    this.statusFilter = '';
    this.filteredUsers = this.users;
  }

  // User operations
  openCreateModal(): void {
    this.showCreateModal = true;
    this.createUserForm.reset();
    this.createUserForm.patchValue({ 
      isActive: true,
      roleIds: [3] // Default to CUSTOMER role
    });
    this.selectedRoleIds.clear();
    this.selectedRoleIds.add(3); // Add default customer role
  }

  closeCreateModal(): void {
    this.showCreateModal = false;
    this.createUserForm.reset();
    this.selectedRoleIds.clear();
  }

  createUser(): void {
    console.log('Create user form submitted');
    console.log('Form valid:', this.createUserForm.valid);
    console.log('Form values:', this.createUserForm.value);
    console.log('Selected role IDs:', Array.from(this.selectedRoleIds));
    
    if (this.createUserForm.valid) {
      this.isLoading = true;
      
      // Format the data before sending
      const formData = { ...this.createUserForm.value };
      
      // Use selected role IDs from checkboxes
      formData.roleIds = Array.from(this.selectedRoleIds);
      if (formData.roleIds.length === 0) {
        formData.roleIds = [3]; // Default to CUSTOMER if none selected
      }
      
      // Ensure date is in correct format (YYYY-MM-DD)
      if (formData.dateOfBirth) {
        const date = new Date(formData.dateOfBirth);
        formData.dateOfBirth = date.toISOString().split('T')[0];
      }

      console.log('User data being sent:', formData);

      this.userManagementService.createUser(formData).subscribe({
        next: (response) => {
          this.isLoading = false;
          console.log('User created successfully:', response);
          this.notificationService.success('User created successfully!');
          
          // Now assign roles if needed (since backend doesn't handle roleIds in registration)
          const userId = response.id || (response as any).userId;
          this.assignRolesToUser(userId, formData.roleIds).then(() => {
            this.loadUsers(); // Refresh the user list
            this.closeCreateModal(); // Close the modal and refresh form
          });
        },
        error: (error) => {
          this.isLoading = false;
          console.error('Error creating user:', error);
          const errorMessage = error.error?.message || error.error?.error || 'Failed to create user. Please try again.';
          this.notificationService.error(errorMessage);
        }
      });
    } else {
      console.log('Form is invalid, marking all fields as touched');
      console.log('Form errors:', this.getFormErrors(this.createUserForm));
      this.markAllFieldsAsTouched();
      this.notificationService.error('Please fill in all required fields correctly');
    }
  }

  // Helper method to assign roles to user after creation
  private async assignRolesToUser(userId: number, roleIds: number[]): Promise<void> {
    try {
      // Only assign non-customer roles since customer is default
      const nonCustomerRoles = roleIds.filter(id => id !== 3);
      
      for (const roleId of nonCustomerRoles) {
        await new Promise<void>((resolve, reject) => {
          this.userManagementService.assignRoleToUser(userId, roleId).subscribe({
            next: () => resolve(),
            error: (error) => reject(error)
          });
        });
      }
    } catch (error) {
      console.error('Error assigning roles:', error);
      // Don't throw error, just log it as user creation was successful
    }
  }

  openEditModal(user: UserDto): void {
    this.selectedUser = user;
    this.showEditModal = true;
    
    // Populate form with user data
    this.editUserForm.patchValue({
      name: user.name,
      email: user.email,
      contactNumber: user.contactNumber,
      address: user.address,
      dateOfBirth: user.dateOfBirth,
      aadharNumber: user.aadharNumber,
      panNumber: user.panNumber,
      gender: user.gender,
      roleIds: user.roles.map(role => role.id),
      isActive: user.isActive
    });
  }

  closeEditModal(): void {
    this.showEditModal = false;
    this.selectedUser = null;
    this.editUserForm.reset();
  }

  updateUser(): void {
    console.log('Update user form submitted');
    console.log('Selected user:', this.selectedUser);
    console.log('Form valid:', this.editUserForm.valid);
    console.log('Form values:', this.editUserForm.value);
    console.log('Form errors:', this.getFormErrors(this.editUserForm));

    if (!this.selectedUser || !this.editUserForm.valid) {
      console.log('Form is invalid or no user selected, marking fields as touched');
      this.markAllEditFieldsAsTouched();
      this.notificationService.error('Please fill in all required fields correctly');
      return;
    }

    this.isLoading = true;
    const formData = this.editUserForm.value;

    // Format the data before sending
    if (formData.dateOfBirth) {
      const date = new Date(formData.dateOfBirth);
      formData.dateOfBirth = date.toISOString().split('T')[0];
    }

    const updateRequest: UpdateUserRequest = {
      name: formData.name,
      email: formData.email,
      contactNumber: formData.contactNumber,
      dateOfBirth: formData.dateOfBirth,
      aadharNumber: formData.aadharNumber,
      panNumber: formData.panNumber,
      gender: formData.gender,
      address: formData.address,
      isActive: formData.isActive,
      roleIds: [] // Role updates handled separately
    };

    console.log('Update request being sent:', updateRequest);

    this.userManagementService.updateUser(this.selectedUser.id!, updateRequest).subscribe({
      next: (response) => {
        this.isLoading = false;
        console.log('User updated successfully:', response);
        this.notificationService.success('User updated successfully');
        this.loadUsers();
        this.closeEditModal();
      },
      error: (error) => {
        this.isLoading = false;
        console.error('Error updating user:', error);
        const errorMessage = error.error?.message || error.error?.error || 'Failed to update user. Please try again.';
        this.notificationService.error('Failed to update user: ' + errorMessage);
      }
    });
  }

  // Helper method to get form errors for debugging
  getFormErrors(form: FormGroup): any {
    let formErrors: any = {};
    Object.keys(form.controls).forEach(key => {
      const controlErrors = form.get(key)?.errors;
      if (controlErrors) {
        formErrors[key] = controlErrors;
      }
    });
    return formErrors;
  }

  // Helper method to mark edit form fields as touched
  private markAllEditFieldsAsTouched(): void {
    Object.keys(this.editUserForm.controls).forEach(key => {
      const control = this.editUserForm.get(key);
      control?.markAsTouched();
    });
  }

  openDeleteModal(user: UserDto): void {
    this.selectedUser = user;
    this.showDeleteModal = true;
  }

  closeDeleteModal(): void {
    this.showDeleteModal = false;
    this.selectedUser = null;
  }

  deleteUser(): void {
    if (this.selectedUser) {
      this.isLoading = true;
      this.userManagementService.deleteUser(this.selectedUser.id!).subscribe({
        next: () => {
          this.notificationService.success('User deactivated successfully');
          this.loadUsers();
          this.closeDeleteModal();
          this.isLoading = false;
        },
        error: (error) => {
          console.error('Error deactivating user:', error);
          this.notificationService.error(error.error?.message || 'Failed to deactivate user');
          this.isLoading = false;
        }
      });
    }
  }

  toggleUserStatus(user: UserDto): void {
    const endpoint = user.isActive ? 'deactivate' : 'activate';
    const action = user.isActive ? 'deactivated' : 'activated';
    
    // Use the appropriate API based on current status
    if (user.isActive) {
      this.userManagementService.deleteUser(user.id!).subscribe({
        next: () => {
          this.notificationService.success(`User ${action} successfully`);
          this.loadUsers();
        },
        error: (error) => {
          console.error(`Error ${endpoint}ing user:`, error);
          this.notificationService.error(`Failed to ${endpoint} user`);
        }
      });
    } else {
      this.userManagementService.toggleUserStatus(user.id!).subscribe({
        next: () => {
          this.notificationService.success(`User ${action} successfully`);
          this.loadUsers();
        },
        error: (error) => {
          console.error(`Error ${endpoint}ing user:`, error);
          this.notificationService.error(`Failed to ${endpoint} user`);
        }
      });
    }
  }

  resetUserPassword(user: UserDto): void {
    this.selectedUser = user;
    this.resetPasswordForm.reset();
    // For now, just show a notification - you can implement a modal if needed
    const newPassword = prompt(`Enter new password for ${user.name}:`);
    if (newPassword && newPassword.length >= 8) {
      this.userManagementService.resetUserPassword(user.id!, newPassword).subscribe({
        next: () => {
          this.notificationService.success('Password reset successfully');
        },
        error: (error) => {
          console.error('Error resetting password:', error);
          this.notificationService.error('Failed to reset password');
        }
      });
    } else if (newPassword) {
      this.notificationService.error('Password must be at least 8 characters long');
    }
  }

  // Utility methods
  getRoleNames(roles: Role[]): string {
    return roles.map(role => role.name).join(', ');
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleDateString();
  }

  // Refresh users method
  refreshUsers(): void {
    this.loadUsers();
    this.loadStatistics();
    this.notificationService.success('User data refreshed successfully');
  }

  // Get filtered users by role for dashboard
  getFilteredUsersByRole(): UserDto[] {
    let filtered = this.filteredUsers;
    
    switch (this.selectedDashboard) {
      case 'ALL':
        // Return all users without role filtering
        return filtered;
      case 'CUSTOMER':
        filtered = filtered.filter(user => user.roles.some(role => role.name === 'CUSTOMER'));
        break;
      case 'EMPLOYEE':
        filtered = filtered.filter(user => user.roles.some(role => role.name === 'EMPLOYEE'));
        break;
      case 'ADMIN':
        filtered = filtered.filter(user => user.roles.some(role => role.name === 'ADMIN'));
        break;
    }
    
    return filtered;
  }

  getDashboardIcon(): string {
    switch (this.selectedDashboard) {
      case 'ALL':
        return '👥';
      case 'CUSTOMER':
        return '👤';
      case 'EMPLOYEE':
        return '👨‍💼';
      case 'ADMIN':
        return '👑';
      default:
        return '�';
    }
  }

  // Form validation helper
  isFieldInvalid(form: FormGroup, fieldName: string): boolean {
    const field = form.get(fieldName);
    return !!(field && field.invalid && field.touched);
  }

  getFieldError(formGroup: FormGroup, fieldName: string): string {
    const field = formGroup.get(fieldName);
    if (field && field.errors && field.touched) {
      if (field.errors['required']) return `${fieldName} is required`;
      if (field.errors['email']) return 'Invalid email format';
      if (field.errors['minlength']) return `Minimum ${field.errors['minlength'].requiredLength} characters required`;
      if (field.errors['pattern']) return 'Invalid format';
    }
    return '';
  }

  // Role selection methods for create user modal
  isRoleSelected(roleId: number): boolean {
    return this.selectedRoleIds.has(roleId);
  }

  onRoleCheckboxChange(event: any, roleId: number): void {
    if (event.target.checked) {
      this.selectedRoleIds.add(roleId);
    } else {
      this.selectedRoleIds.delete(roleId);
    }
  }

  // Statistics methods for the dashboard
  getTotalUsers(): number {
    return this.users.length;
  }

  getActiveUsers(): number {
    return this.users.filter(user => user.isActive).length;
  }

  getActiveUsersCount(): number {
    return this.getActiveUsers();
  }

  getInactiveUsersCount(): number {
    return this.users.filter(user => !user.isActive).length;
  }

  getAdminUsersCount(): number {
    return this.getUsersByRole('ADMIN').length;
  }

  getEmployeeUsersCount(): number {
    return this.getUsersByRole('EMPLOYEE').length;
  }

  getCustomerUsersCount(): number {
    return this.getUsersByRole('CUSTOMER').length;
  }

  // Dashboard navigation methods
  setActiveTab(tab: string): void {
    // Since we removed tabs, we can just trigger a refresh or specific action
    if (tab === 'statistics') {
      this.loadStatistics();
    }
  }

  getDashboardTitle(): string {
    switch (this.selectedDashboard) {
      case 'ALL':
        return '👥 All Users Management';
      case 'CUSTOMER':
        return '👤 Customer Management';
      case 'EMPLOYEE':
        return '👨‍💼 Employee Management';
      case 'ADMIN':
        return '👑 Administrator Management';
      default:
        return '👥 User Management';
    }
  }

  getDashboardDescription(): string {
    switch (this.selectedDashboard) {
      case 'ALL':
        return 'Manage all user accounts and roles across the system';
      case 'CUSTOMER':
        return 'Manage customer accounts and profiles';
      case 'EMPLOYEE':
        return 'Manage employee accounts and permissions';
      case 'ADMIN':
        return 'Manage administrator accounts and system access';
      default:
        return 'Manage all user accounts and roles';
    }
  }

  // Helper method to mark create form fields as touched
  private markAllFieldsAsTouched(): void {
    Object.keys(this.createUserForm.controls).forEach(key => {
      const control = this.createUserForm.get(key);
      control?.markAsTouched();
    });
  }

  getUsersByRole(roleName: string): UserDto[] {
    return this.users.filter(user => 
      user.roles.some(role => role.name.toUpperCase() === roleName.toUpperCase())
    );
  }
}
