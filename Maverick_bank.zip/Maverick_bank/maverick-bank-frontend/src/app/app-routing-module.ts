import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccountManagementComponent } from './components/account-management/account-management.component';
import { EmployeeAccountManagementComponent } from './components/employee-account-management/employee-account-management.component';
import { CustomerAccountRequestComponent } from './components/customer-account-request/customer-account-request.component';
import { LoanManagementComponent } from './components/loan-management/loan-management.component';
import { LoanTypeManagementComponent } from './components/loan-type-management/loan-type-management.component';
import { CustomerReportsPageComponent } from './components/customer-reports-page/customer-reports-page.component';
import { EmployeeReportsPageComponent } from './components/employee-reports-page/employee-reports-page.component';
import { AuthGuard } from './guards/auth.guard';
import { RoleGuard } from './guards/role.guard';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  
  // Main dashboard (role-based rendering)
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  
  // Admin-specific route for the admin dashboard directly
  { path: 'admin', component: DashboardComponent, canActivate: [AuthGuard, RoleGuard], data: { roles: ['ADMIN'] } },
  
  // Core features
  { path: 'accounts', component: AccountManagementComponent, canActivate: [AuthGuard] },
  
  // Customer-specific features
  { 
    path: 'request-account', 
    component: CustomerAccountRequestComponent, 
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['CUSTOMER'] }
  },
  
  // Loan management routes
  { 
    path: 'loan-management', 
    component: LoanManagementComponent, 
    canActivate: [AuthGuard] 
  },
  { 
    path: 'loan-type-management', 
    component: LoanTypeManagementComponent, 
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['ADMIN'] }
  },
  
  // Employee-specific features
  { 
    path: 'employee-accounts', 
    component: EmployeeAccountManagementComponent, 
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['EMPLOYEE', 'ADMIN'] }
  },
  
  // Reports features
  { 
    path: 'customer-reports', 
    component: CustomerReportsPageComponent, 
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['CUSTOMER'] }
  },
  { 
    path: 'employee-reports', 
    component: EmployeeReportsPageComponent, 
    canActivate: [AuthGuard, RoleGuard],
    data: { roles: ['EMPLOYEE', 'ADMIN'] }
  },
  
  { path: '**', redirectTo: '/login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
