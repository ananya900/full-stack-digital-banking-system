import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { AuthService } from '../services/auth.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  canActivate(): Observable<boolean> {
    const token = this.authService.getToken();
    
    // If no token or token is expired, redirect to login
    if (!token || this.authService.isTokenExpired(token)) {
      this.router.navigate(['/']);
      return of(false);
    }
    
    // If user is already loaded, allow access
    const currentUser = this.authService.getCurrentUser();
    if (currentUser) {
      return of(true);
    }
    
    // If token exists but user not loaded, load user profile first
    this.authService.loadUserProfile();
    return of(true);
  }
}
