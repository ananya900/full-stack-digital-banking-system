#!/bin/bash

# Maverick Bank Frontend Test Script
# This script performs basic functionality tests

echo "🚀 Starting Maverick Bank Frontend Tests..."
echo "============================================"

# Test 1: Check if application is running
echo "📡 Testing application availability..."
if curl -s http://localhost:65512 >/dev/null; then
    echo "✅ Application is running on http://localhost:65512"
else
    echo "❌ Application is not accessible. Please start the development server first."
    echo "   Run: npm start"
    exit 1
fi

# Test 2: Check if login page loads
echo "🔐 Testing login page..."
if curl -s http://localhost:65512/login >/dev/null; then
    echo "✅ Login page is accessible"
else
    echo "❌ Login page is not accessible"
fi

# Test 3: Check if register page loads
echo "📝 Testing register page..."
if curl -s http://localhost:65512/register >/dev/null; then
    echo "✅ Register page is accessible"
else
    echo "❌ Register page is not accessible"
fi

echo ""
echo "🎯 Manual Test Checklist:"
echo "========================="
echo "1. ✓ Open http://localhost:65512 in your browser"
echo "2. ✓ Try logging in with test credentials:"
echo "   - Username: admin, Password: password123"
echo "   - Username: employee, Password: password123"
echo "   - Username: customer, Password: password123"
echo "3. ✓ Click on test credentials to auto-fill the form"
echo "4. ✓ Test registration with sample data"
echo "5. ✓ Verify dashboard access after login"
echo "6. ✓ Test logout functionality"
echo "7. ✓ Check responsive design on different screen sizes"
echo ""
echo "🏁 Basic connectivity tests completed!"
echo "For full testing, perform the manual checklist above."
