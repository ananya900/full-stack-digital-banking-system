package com.maverickbank;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Unit test for simple App.
 */
public class AppTest {
    @Test
    public void testApp() {
        assertTrue(true);
    }
}
